﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Core_res))]
public class Core_Spawn : Errors
{
	[SerializeField] private Config config;
	[SerializeField] private List<Sattings_Block_Created_Level> lprefab_Go = new List<Sattings_Block_Created_Level>();
	[SerializeField, BigString(3, 10)] private string stGuiJsonp = "{}";
	private GameObject player;
	private Core_res core_Res;

	private List<Prefab_Go> prg;
	private ManagerGuiCr items;

	public void GuiCrMan(string st)
	{
		if (items == null)
			return;

		string clean = st.Replace("\n", "").Replace(" ", "");
		if (string.IsNullOrEmpty(clean) || !JsonP.IsValidJson(clean))
			return;

		items.JsonPManagerGuiCr(clean);
	}

	private Prefab_Go selec(Sattings_Block_Created_Level sbcl)
	{
		if (sbcl == null) return null;
		return sbcl.sbc.Obj[sbcl.lev];
	}

	void Awake()
	{
		core_Res = gameObject.GetComponent<Core_res>();
		prg = new List<Prefab_Go>(World_command.ProcessObjects<Sattings_Block_Created_Level, Prefab_Go>(lprefab_Go, selector: selec));
		GuiCrMan(stGuiJsonp.Replace("\n", "").Replace(" ", ""));
	}

	protected override bool StTestError()
	{
		return config != null && core_Res != null;
	}

	void Start()
	{
		config.created_pl(transform.position, lprefab_Go, core_Res, ref player, config, ref items);
	}

	void Update()
	{
		if (player == null)
		{
			config.created_pl(transform.position, lprefab_Go, core_Res, ref player, config, ref items);
		}
	}
}
