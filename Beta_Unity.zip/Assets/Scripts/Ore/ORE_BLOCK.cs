﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Ore_Name
{
	string Name();
}

public struct Type_dobl<T, T2>
{
	public T one;
	public T2 two;

	public Type_dobl(T one, T2 two)
	{
		this.one = one;
		this.two = two;
	}
}

public abstract class New_ore : Ore_Name
{
	private string name = "New_ore";
	private bool fire_toplivo = false;
	private Dictionary<string, string> DicDeffult = new Dictionary<string, string>();

	public New_ore() { }

	public New_ore(
		string name,
		bool fire_toplivo,
		Dictionary<string, string> newSvoystva
	)
	{
		this.name = name;
		this.fire_toplivo = fire_toplivo;
		DicDeffult = newSvoystva;
	}

	public virtual Dictionary<string, string> New_Svoystvo() { return DicDeffult; }


	public string Name() { return name; }
	public virtual Type_dobl<float, float> RandMineTimeSleep() { return new Type_dobl<float, float>(0.01f, 0.15f); }
	public virtual bool FireToplivo() { return fire_toplivo; }
}

public class Flammogidrid : New_ore
{
	public new string Name() { return "Coal"; }
	public override bool FireToplivo() { return true; }
}

public struct Len_List_Vec
{
	public int len;
	public List<Vector3> vec;
	public Len_List_Vec(List<Vector3> vec)
	{
		len = vec.Count;
		this.vec = vec;
	}
}

public class ORE_BLOCKS
{
	public static List<GameObject> GetOreInMy(GameObject go, List<string> ore_type)
	{
		var gam = new List<GameObject>();
		var comp = go.GetComponent<World_class_move>();
		if (comp == null)
			World_command.Error(go.name, "not exemplar scripts World_class_move");

		List<DicVec.GameInfo> hits = Config.Get_obg_size_scene(go, DicVec.Generated.Mine_blick);

		SattingsOre sore;

		foreach (DicVec.GameInfo hitCollider in hits)
		{
			if (hitCollider.go == null || hitCollider.typeGenerated == null) continue;
			sore = hitCollider.typeGenerated as SattingsOre;

			if (sore != null && ore_type.Contains(sore.ore))
				gam.Add(hitCollider.go);
		}
		return gam;
	}

	public static string Null { get { return ""; } }

	public static bool IfNullOre(string st)
	{
		return st == Null;
	}
}