﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SattingsOre : DicVec.TypeGenerated
{
	public SattingsOre(string ore)
	{
		this.ore = ore;
	}
	public DicVec.Generated GetTypeGenerated() { return DicVec.Generated.Mine_blick; }
	public string ore = ORE_BLOCKS.Null;
}

public class Ore : MonoBehaviour
{
	[SerializeField, Delayed] private string _ore = ORE_BLOCKS.Null;
	[SerializeField, Delayed] private int _ore_mine_defect = 0;
	public string ore { get { return _ore; } }
	public int ore_mine_defect { get { return _ore_mine_defect; } }

	void Awake()
	{
		Config.Add_obg_scene(gameObject, new SattingsOre(_ore));
	}

	void OnDestroy()
	{
		Config.Destroy_obj_size_scene(gameObject, DicVec.Generated.Mine_blick);
	}
}
