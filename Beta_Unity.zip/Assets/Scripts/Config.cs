﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

[System.Serializable]
public struct State_cr
{
	public GameObject Act;
	public GameObject notAct;

	public State_cr(GameObject act, GameObject notAct)
	{
		Act = act;
		this.notAct = notAct;
	}
}

public class Config : Errors
{
	[SerializeField] private Sprite Ico_Defult;
	[SerializeField] private State_cr state_create_block;
	[SerializeField] private List<DicVec.TypeGenerated> prefabs_sattings = new List<DicVec.TypeGenerated>();
	private static DicVec obg_scene = new DicVec();

	public Sprite GetDefultIco()
	{
		return Ico_Defult;
	}

	public State_cr GetRenderStateCrBl()
	{
		return state_create_block;
	}

	public static bool Test_Cr_Bl(GameObject obj, DicVec.TypeGenerated sattings)
	{
		if (obj == null || sattings == null) return false;
		foreach (var pos in World_command.GetCellCenters(obj))
		{
			if (!obg_scene.TestCreateBlock(pos, sattings))
			{
				return true;
			}
		}
		return false;
	}

	public List<DicVec.TypeGenerated> get_prefabs()
	{
		return prefabs_sattings;
	}

	public static void Add_obg_scene(GameObject g, DicVec.TypeGenerated sattings_Block_Cr)
	{
		if (g.GetComponent<BoxCollider>() == null) World_command.Error(g.name, "not component BoxCollaider");
		List<Vector3> vec = World_command.GetCellCenters(g);
		foreach (Vector3 ve in vec)
		{
			if (obg_scene.GetAllInCellGo(ve, sattings_Block_Cr.GetTypeGenerated()).Contains(g)) return;
		}
		if (vec.Count == 0) return;
		foreach (Vector3 vect in vec)
		{
			obg_scene.Add(g, vect, sattings_Block_Cr);
		}
	}

	public static List<GameObject> GetBlockRadScene(Vector3 pos, Vector3 size, DicVec.Generated generated)
	{
		return World_command.ProcessObjects<DicVec.GameInfo, GameObject>(obg_scene.GetInBoxWithSize(pos, size, generated), selector: t);
	}

	public static bool If_Set_Block(GameObject g, DicVec.Generated generated)
	{
		return obg_scene.GetAllInCell(g.transform.position, generated) == null;
	}

	public static List<DicVec.GameInfo> Get_obg_size_scene(GameObject go, DicVec.Generated generated)
	{
		if (go == null || go.GetComponent<BoxCollider>() == null) World_command.Error(go.name, "not component BoxCollaider");
		return obg_scene.GetInBoxWithSize(go.transform.position, go.GetComponent<BoxCollider>().size, generated);
	}

	public static List<DicVec.GameInfo> Get_obg_scene(Vector3 vec, DicVec.Generated generated)
	{
		return obg_scene.GetAllInCell(vec, generated);
	}

	private static GameObject t(DicVec.GameInfo gi) { return gi.go; }
	public static List<GameObject> Get_obg_sceneGo(Vector3 vec, DicVec.Generated generated)
	{
		return World_command.ProcessObjects<DicVec.GameInfo, GameObject>(obg_scene.GetAllInCell(vec, generated), selector: t);
	}

	public static List<GameObject> Get_Box_obg_scene(Vector3 vec, DicVec.Generated generated, float rad = 0.1f)
	{
		return World_command.ProcessObjects<DicVec.GameInfo, GameObject>(obg_scene.GetInBox(vec, rad, generated), selector: t);
	}

	public static void Destroy_obj_scene(GameObject g, DicVec.Generated generated)
	{
		obg_scene.Remove(g, g.transform.position, generated);
	}

	public static void Destroy_obj_size_scene(GameObject g, DicVec.Generated generated)
	{
		foreach (Vector3 ve in World_command.GetCellCenters(g))
		{
			obg_scene.Remove(g, ve, generated);
		}
	}

	public static void Destroy_obj_all_pos_scene(Vector3 vec, DicVec.Generated generated)
	{
		List<Vector3> vecl;
		foreach (DicVec.GameInfo g in obg_scene.GetAllInCell(vec, generated))
		{
			vecl = World_command.GetCellCenters(g.go);
			foreach (Vector3 ve in vecl)
			{
				obg_scene.Remove(g.go, ve, generated);
			}
		}
	}

	public static void Destroy_rad_obj_scene(Vector3 vec, float rad, DicVec.Generated generated)
	{
		obg_scene.RemoveInBox(vec, rad, generated);
	}

	[SerializeField] private GameObject player_prefab;

	private Prefab_Go sbcinprg(Sattings_Block_Created_Level sbcl)
	{
		return sbcl.sbc.Obj[sbcl.lev];
	}

	public void created_pl(Vector3 pos, List<Sattings_Block_Created_Level> lprefab_Go, Core_res g, ref GameObject go, Config conf, ref ManagerGuiCr mgc)
	{
		if (go == null && player_prefab != null)
		{
			go = Instantiate(player_prefab, new Vector3(pos.x, 2, pos.z), player_prefab.transform.rotation);
			var movp = go.GetComponent<Move_person>();
			if (go.GetComponent<Created_block>() == null || movp == null)
			{
				Destroy(go);
				World_command.Error(gameObject.name, "error get component");
				return;
			}
			g.MainCam = movp.MainCam;
			if (mgc == null) mgc = new ManagerGuiCr(go);
			mgc.ReGameObject(go);
		}
		else
		{
			World_command.Error(gameObject.name, "created act player");
		}
	}
}