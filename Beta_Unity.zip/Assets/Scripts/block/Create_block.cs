﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public struct ResursesCraft
{
	public string ore;
	public int len_ore;

	public ResursesCraft(string ore, int len_ore)
	{
		this.ore = ore;
		this.len_ore = len_ore;
	}
}