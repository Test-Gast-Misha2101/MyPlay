﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomPropertyDrawer(typeof(BigStringAttribute))]
public class BigStringDrawer : PropertyDrawer
{
    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        var attr = (BigStringAttribute)attribute;

        float lineHeight = EditorGUIUtility.singleLineHeight;
        float height = lineHeight * attr.maxLines;

        Rect textAreaRect = new Rect(position.x, position.y, position.width, height);

        EditorGUI.BeginProperty(position, label, property);
        {
            property.stringValue = EditorGUI.TextArea(textAreaRect, property.stringValue, EditorStyles.textArea);
        }
        EditorGUI.EndProperty();
    }

    public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
    {
        var attr = (BigStringAttribute)attribute;
        return EditorGUIUtility.singleLineHeight * attr.maxLines;
    }
}