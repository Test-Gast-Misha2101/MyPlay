﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

[System.Serializable]
public class Sattings_Block_Created_Level
{
	public Sattings_block_cr sbc;
	public int lev;

	public Sattings_Block_Created_Level(Sattings_block_cr sattings_Block_Cr, int level)
	{
		sbc = sattings_Block_Cr;
		this.lev = level;
	}
}

[System.Serializable]
public class Prefab_Go
{
	[Header("Name")]
	public string name;
	[Header("Ico")]
	public Sprite ico;
	[Header("Obj_Preferences")]
	public GameObject Prefab;
	public Vector3 vecPrSmetheniePaste;
	public GameObject go;
	[Header("Grup")]
	public string grup;
	public string sortGrup;
	[Header("Craft")]
	public List<ResursesCraft> resursesCrafts;
}

[CreateAssetMenu(fileName = "New_Sattings_Create_Block", menuName = "Scripteble_obg/Block/Create/Sattings_create_block")]
public class Sattings_block_cr : ScriptableObject
{
	[Header("Base_Preferences")]
	public List<Prefab_Go> Obj = new List<Prefab_Go>();
}

public class PlayerBlock : DicVec.TypeGenerated
{
	public DicVec.Generated GetTypeGenerated() { return DicVec.Generated.Player_Block; }
}