﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

public class WorldGoDisasamble
{
    [AttributeUsage(AttributeTargets.Field)]
    public class VarDisasemble : Attribute { }

    [Serializable]
    public class FieldEntry
    {
        public string name;
        public string type;
        public string json;
    }

    [Serializable]
    public class ComponentEntry
    {
        public string typeName;
        public List<FieldEntry> fields = new List<FieldEntry>();
    }

    [Serializable]
    public class Blueprint
    {
        public string name;
        public int layer;
        public string tag;
        public bool active;
        public bool isRectTransform;
        public Vector3 pos;
        public Quaternion rot;
        public Vector3 scale;
        public Vector2 anchorMin;
        public Vector2 anchorMax;
        public Vector2 offsetMin;
        public Vector2 offsetMax;
        public Vector2 pivot;
        public Vector2 sizeDelta;
        public List<ComponentEntry> components = new List<ComponentEntry>();
    }

    public static Blueprint Disassemble(GameObject go)
    {
        var bp = new Blueprint
        {
            name = go.name,
            layer = go.layer,
            tag = go.tag,
            active = go.activeSelf
        };

        var rt = go.transform as RectTransform;
        if (rt != null)
        {
            bp.isRectTransform = true;
            bp.pos = rt.localPosition;
            bp.rot = rt.localRotation;
            bp.scale = rt.localScale;
            bp.anchorMin = rt.anchorMin;
            bp.anchorMax = rt.anchorMax;
            bp.offsetMin = rt.offsetMin;
            bp.offsetMax = rt.offsetMax;
            bp.pivot = rt.pivot;
            bp.sizeDelta = rt.sizeDelta;
        }
        else
        {
            bp.isRectTransform = false;
            bp.pos = go.transform.localPosition;
            bp.rot = go.transform.localRotation;
            bp.scale = go.transform.localScale;
        }

        foreach (var comp in go.GetComponents<Component>())
        {
            if (comp is Transform) continue;
            if (comp is CanvasRenderer) continue;

            var t = comp.GetType();
            var entry = new ComponentEntry { typeName = t.AssemblyQualifiedName };

            foreach (var f in GetFields(t))
                entry.fields.Add(new FieldEntry
                {
                    name = f.Name,
                    type = f.FieldType.AssemblyQualifiedName,
                    json = ToJson(f.GetValue(comp), f.FieldType)
                });

            bp.components.Add(entry);
        }

        return bp;
    }

    public static GameObject Assemble(Blueprint bp, Transform parent = null)
    {
        var go = new GameObject(bp.name);
        go.layer = bp.layer;
        go.tag = bp.tag;
        go.SetActive(bp.active);

        if(parent != null)
		{
            go.transform.SetParent(parent, false);
		}

        if (bp.isRectTransform)
        {
            var rt = go.AddComponent<RectTransform>();
            rt.localPosition = bp.pos;
            rt.localRotation = bp.rot;
            rt.localScale = bp.scale;
            rt.anchorMin = bp.anchorMin;
            rt.anchorMax = bp.anchorMax;
            rt.offsetMin = bp.offsetMin;
            rt.offsetMax = bp.offsetMax;
            rt.pivot = bp.pivot;
            rt.sizeDelta = bp.sizeDelta;
        }
        else
        {
            go.transform.localPosition = bp.pos;
            go.transform.localRotation = bp.rot;
            go.transform.localScale = bp.scale;
        }

        var ordered = World_command.ProcessObjects<ComponentEntry, ComponentEntry>(
            bp.components,
            null,
            null
        );
        ordered.Sort((a, b) =>
            ComponentPriority(Type.GetType(b.typeName))
            .CompareTo(ComponentPriority(Type.GetType(a.typeName))));

        foreach (var ce in ordered)
        {
            var t = Type.GetType(ce.typeName);
            if (t == null || t == typeof(CanvasRenderer)) continue;

            var comp = go.GetComponent(t);
            if (comp == null) comp = go.AddComponent(t);

            foreach (var fe in ce.fields)
            {
                var fields = GetFields(t);
                FieldInfo found = null;
                foreach (var f in fields)
                {
                    if (f.Name == fe.name) { found = f; break; }
                }
                if (found == null) continue;

                var ft = Type.GetType(fe.type);
                if (ft == null) continue;
                found.SetValue(comp, FromJson(fe.json, ft));
            }
        }

        return go;
    }

    private static int ComponentPriority(Type t)
    {
        if (t == null) return 0;
        if (t == typeof(Canvas)) return 100;
        if (t == typeof(UnityEngine.UI.CanvasScaler)) return 90;
        if (t == typeof(UnityEngine.UI.GraphicRaycaster)) return 80;
        if (typeof(UnityEngine.UI.Graphic).IsAssignableFrom(t)) return 70;
        return 0;
    }

    private static IEnumerable<FieldInfo> GetFields(Type t)
    {
        var pub = World_command.ProcessObjects<FieldInfo, FieldInfo>(
            new List<FieldInfo>(
                t.GetFields(BindingFlags.Public | BindingFlags.Instance)),
            f => !Attribute.IsDefined(f, typeof(NonSerializedAttribute)),
            null
        );

        var privSerialize = World_command.ProcessObjects<FieldInfo, FieldInfo>(
            new List<FieldInfo>(
                t.GetFields(BindingFlags.NonPublic | BindingFlags.Instance)),
            f => Attribute.IsDefined(f, typeof(SerializeField)),
            null
        );

        var privBlueprint = World_command.ProcessObjects<FieldInfo, FieldInfo>(
            new List<FieldInfo>(
                t.GetFields(BindingFlags.NonPublic | BindingFlags.Instance)),
            f => Attribute.IsDefined(f, typeof(VarDisasemble)),
            null
        );

        var result = new List<FieldInfo>(pub.Count + privSerialize.Count + privBlueprint.Count);
        result.AddRange(pub);
        result.AddRange(privSerialize);
        result.AddRange(privBlueprint);
        return result;
    }

    private static string ToJson(object val, Type t)
    {
        if (val == null) return "null";
        if (t == typeof(string)) return (string)val;
        if (t == typeof(int) || t == typeof(float) || t == typeof(bool)
            || t == typeof(double) || t == typeof(long))
            return val.ToString();
        if (t.IsEnum) return val.ToString();
        if (typeof(UnityEngine.Object).IsAssignableFrom(t))
        {
            var uo = (UnityEngine.Object)val;
            return "ref:" + (uo != null ? uo.name : "null");
        }
        try { return JsonUtility.ToJson(val); }
        catch { return "null"; }
    }

    private static object FromJson(string json, Type t)
    {
        if (json == "null") return null;
        if (t == typeof(string)) return json;
        if (t == typeof(int)) return int.Parse(json);
        if (t == typeof(float)) return float.Parse(json);
        if (t == typeof(bool)) return bool.Parse(json);
        if (t == typeof(double)) return double.Parse(json);
        if (t == typeof(long)) return long.Parse(json);
        if (t.IsEnum) return Enum.Parse(t, json);
        if (typeof(UnityEngine.Object).IsAssignableFrom(t)) return null;
        try { return JsonUtility.FromJson(json, t); }
        catch { return null; }
    }
}