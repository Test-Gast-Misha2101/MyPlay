﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Move_person : Errors
{
	[SerializeField, Delayed] private float speed = 5;
	[SerializeField, Delayed] private float move_x = 6.0f;
	[SerializeField] private Camera cam;
	[SerializeField] private RectTransform Ui_Items_cr;
	public Camera MainCam { get { return cam; } }
	public Core_Spawn coreSp { get; set; }
	private float hor_m = 0f;

	protected override bool AwTestError()
	{
		return MainCam != null;
	}

	void Update()
	{
		if (Cursor.lockState == CursorLockMode.Locked && !Cursor.visible)
		{
			hor_m += Input.GetAxis("Mouse X") * move_x;
			transform.localRotation = Quaternion.Euler(transform.rotation.x, hor_m, transform.rotation.z);
		}
	}

	void FixedUpdate()
	{
		if (Cursor.lockState == CursorLockMode.Locked && !Cursor.visible)
		{
			float hor = Input.GetAxis("Horizontal");
			float ver = Input.GetAxis("Vertical");

			Vector3 vec = new Vector3(hor, 0f, ver);

			transform.Translate(vec * speed * 0.03f, Space.Self);
		}
	}
}