﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonCreateBlock : MonoBehaviour {
	[SerializeField] private Created_block Player;
	[SerializeField] private Prefab_Go sattings;

	public void SetParametr(Created_block pl, Prefab_Go sattings)
	{
		if (pl == null || sattings == null) World_command.Error(gameObject.name, "parametrs == null in created");
		Player = pl;
		this.sattings = sattings;
	}

	public void CreateBlock()
	{
		Player.Create_block_Render(sattings);
	}
}
