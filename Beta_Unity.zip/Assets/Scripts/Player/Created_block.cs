﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Move_person))]
public class Created_block : Errors
{
	[SerializeField] private LayerMask layer;
	[SerializeField] private Config conf;
	private Camera cam;
	private DicVec.GamePlayerBuildBlock Obj = new DicVec.GamePlayerBuildBlock();
	private Vector3 SizeObj = Vector3.one;
	private Quaternion quaternion1 = Quaternion.identity;
	private GameObject _renderChild;
	private bool _go_state;
	private Vector3 _hit_pos = Vector3.zero;
	private Vector3 smeschenie = Vector3.zero;
	private DicVec.TypeGenerated TypeGenerated;
	private List<DicVec.GamePlayerBuildBlock> Obj_coninue_create = new List<DicVec.GamePlayerBuildBlock>();

	public void Rotarions(Quaternion quaternion)
	{
		if (quaternion.x >= -360 || quaternion.x <= 360 || quaternion.y >= -360 || quaternion.y <= 360 || quaternion.z >= -360 || quaternion.z <= 360)
		{
			quaternion1 = quaternion;
		}
		else
		{
			World_command.Error(gameObject.name, "In Rotarions set big float or miny float");
		}
	}

	void Awake()
	{
		var com = gameObject.GetComponent<Move_person>();
		cam = com.MainCam;
		if (com == null || cam == null) World_command.Error(gameObject.name, "not component Camera");
	}

	protected override bool StTestError()
	{
		return cam != null;
	}

	public void Create_block_Render(Prefab_Go sbc)
	{
		if (cam == null) return;
		if (sbc == null) World_command.Error(gameObject.name, "not prefab in Sattings_block_create");
		if (sbc.Prefab == null || sbc.go == null || sbc.Prefab.GetComponent<BoxCollider>() == null) World_command.Error(gameObject.name, "In Sattings_block_cr gameObgect not component BoxCollider");
		if (sbc == null) return;
		if (Obj.go != null) { Destroy(Obj.go); }
		Obj.go = Instantiate(sbc.Prefab);
		Obj.sattings = sbc;
		SizeObj = Obj.go.GetComponent<BoxCollider>().size;
		TypeGenerated = new PlayerBlock();
	}

	private void CrBlRenderColor(Vector3 vec, Quaternion quaternion, Vector3 size, bool act)
	{
		State_cr rgo = conf.GetRenderStateCrBl();
		if (rgo.Act == null || rgo.notAct == null)
		{
			World_command.Error(gameObject.name, "Not obj RenderObj");
			return;
		}

		GameObject go = act ? rgo.Act : rgo.notAct;
		if (go == null)
		{
			World_command.Error(gameObject.name, "Not obg in Renderer in " + (act ? "Act" : "notAct"));
			return;
		}

		if (_renderChild == null || act != _go_state)
		{
			if (_renderChild != null) Destroy(_renderChild);
			_renderChild = Instantiate(go, vec, quaternion, Obj.go.transform);
			_renderChild.transform.localScale = size + new Vector3(0.1f, 0.1f, 0.1f);
			_go_state = act;
		}
		else
		{
			_renderChild.transform.position = vec;
			_renderChild.transform.rotation = quaternion;
			_renderChild.transform.localScale = size + new Vector3(0.1f, 0.1f, 0.1f);
		}
	}


	private void Set_bl_cr(Vector3 vec, Quaternion quaternion)
	{
		if (cam == null) return;
		if (Obj.child != null) { Destroy(Obj.child); Obj.child = null; }
		if (Obj.go == null || Obj.sattings.go == null || Obj.sattings.Prefab == null) return;
		Destroy(Obj.go);
		GameObject go = Instantiate(Obj.sattings.go, vec, quaternion);
		if (Config.Test_Cr_Bl(go, TypeGenerated))
		{
			World_command.Error(gameObject.name, "block created > max in block");
		}
		go.layer = LayerMask.NameToLayer("Collaider");
		Config.Add_obg_scene(go, TypeGenerated);
		MainSystemTrigers.ResetClTr();
		Obj.go = null;
		Obj.sattings = null;
		MainSystemTrigers.RegistTrig(MainSystemTrigers.trig.Update_Block);
	}

	void Update()
	{
		if (Obj.go != null && Obj.sattings != null)
		{
			if (cam == null)
			{
				Destroy(Obj.go);
				Obj.sattings = null;
				Destroy(Obj.child);
			}
			Ray ray = cam.ScreenPointToRay(Input.mousePosition);
			RaycastHit hit;
			if (Physics.Raycast(ray, out hit, 100f, layer))
			{
				_hit_pos = (hit.point + new Vector3(0, SizeObj.y / 2, 0)) + hit.normal * 0.1f;
				smeschenie = Obj.sattings.vecPrSmetheniePaste;
				_hit_pos = new Vector3((Mathf.Floor(_hit_pos.x) + 0.5f) + smeschenie.x, Mathf.Floor(_hit_pos.y) + smeschenie.y, (Mathf.Floor(_hit_pos.z) + 0.5f) + smeschenie.z);
				Obj.go.transform.position = _hit_pos;
				if (!Config.Test_Cr_Bl(Obj.go, TypeGenerated))
				{
					CrBlRenderColor(Obj.go.transform.position, Quaternion.identity, SizeObj, true);
					if (Input.GetMouseButtonDown(0))
					{
						Set_bl_cr(_hit_pos, quaternion1);
					}
				}
				else
				{
					CrBlRenderColor(Obj.go.transform.position, Quaternion.identity, SizeObj, false);
				}
			}
			else
			{
				CrBlRenderColor(Obj.go.transform.position, Quaternion.identity, SizeObj, false);
			}
		}
	}

}
