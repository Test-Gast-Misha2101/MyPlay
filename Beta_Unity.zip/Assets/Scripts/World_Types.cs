﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace World_Types {
	public class Dic_Rdic<TKey, TValue> : IEnumerable { 
		private Dictionary<TKey, TValue> dic;
		private Dictionary<TValue, TKey> rdic;

		public IEnumerator GetEnumerator()
		{
			return dic.GetEnumerator();
		}

		public Dic_Rdic()
		{
			dic = new Dictionary<TKey, TValue>();
			rdic = new Dictionary<TValue, TKey>();
		}

		public Dic_Rdic(Dic_Rdic<TKey, TValue> dic_Rdic)
		{
			dic = new Dictionary<TKey, TValue>(dic_Rdic.Get());
			rdic = new Dictionary<TValue, TKey>(dic_Rdic.RGet());
		}

		public Dic_Rdic(Dic_Rdic<TValue, TKey> dic_Rdic)
		{
			dic = new Dictionary<TKey, TValue>(dic_Rdic.RGet());
			rdic = new Dictionary<TValue, TKey>(dic_Rdic.Get());
		}

		public Dictionary<TKey, TValue> Get()
		{
			return dic;
		}

		public Dictionary<TValue, TKey> RGet()
		{
			return rdic;
		}

		public void Add(TKey key, TValue value)
		{
			Set(key, value);
		}

		public List<TKey> Key()
		{
			return new List<TKey>(dic.Keys);
		}

		public List<TValue> Value()
		{
			return new List<TValue>(rdic.Keys);
		}

		public TValue GetValue(TKey key, TValue baseValue)
		{
			TValue value;
			if (dic.TryGetValue(key, out value))
			{
				return value;
			}
			return baseValue;
		}

		public TKey GetValue(TValue value, TKey baseValue)
		{
			TKey key;
			if (rdic.TryGetValue(value, out key))
			{
				return key;
			}
			return baseValue;
		}

		public void Remove(TKey key)
		{
			TValue value;
			if (!dic.TryGetValue(key, out value))
				return;
			dic.Remove(key);
			rdic.Remove(value);
		}

		public void Remove(TValue value)
		{
			TKey key;
			if (!rdic.TryGetValue(value, out key))
				return;
			rdic.Remove(value);
			dic.Remove(key);
		}

		public void Clear()
		{
			dic.Clear();
			rdic.Clear();
		}

		public bool ContainsKey(TKey key) { return dic.ContainsKey(key); }
		public bool ContainsValue(TValue v) { return rdic.ContainsKey(v); }
		public int Count { get { return dic.Count; } }
		public TKey this[TValue key]
		{
			get { return rdic[key]; }
			set { Set(value, key); }
		}
		public TValue this[TKey key]
		{
			get { return dic[key]; }
			set { Set(key, value); }
		}

		public bool TryGetKey(TValue value, out TKey key)
		{
			return rdic.TryGetValue(value, out key);
		}

		public bool TryGetValue(TKey key, out TValue value)
		{
			return dic.TryGetValue(key, out value);
		}

		private void Set(TKey key, TValue value)
		{
			TValue oldValue;
			if (dic.TryGetValue(key, out oldValue))
				rdic.Remove(oldValue);

			TKey oldKey;
			if (rdic.TryGetValue(value, out oldKey))
				dic.Remove(oldKey);

			dic[key] = value;
			rdic[value] = key;
		}

	}
}