﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using System;

public class ManagerGuiCr
{
	private Dictionary<string, ManagerGuiCr> mgc = new Dictionary<string, ManagerGuiCr>();
	public GameObject Go { get; private set; }
	public WorldGoDisasamble.Blueprint wd { get; private set; }

	private Dictionary<string, Type> destroyType = new Dictionary<string, Type>() {
		{"Img", typeof(Image)},
		{"Text", typeof(Text)},
		{"RawImage", typeof(RawImage)},
		{"Mask", typeof(Mask)},
		{"RectMask2D", typeof(RectMask2D)},
		{"Button", typeof(Button)},
		{"InputField", typeof(InputField)},
		{"Toggle", typeof(Toggle)},
		{"ToggleGroup", typeof(ToggleGroup)},
		{"Slider", typeof(Slider)},
		{"Scrollbar", typeof(Scrollbar)},
		{"Dropdown", typeof(Dropdown)},
		{"ScrollRect", typeof(ScrollRect)},
	};

	private void AssambleJsonUiObject(GameObject go, string jsonc, Dictionary<string, Dictionary<string, GameObject>> dic)
	{
		JsonP json = new JsonP(jsonc);
		JsonP JP;
		List<string> ls;

		if(json.TryGetValue("Rect", out JP) && JP != null) {
			RectTransform rt = go.GetComponent<RectTransform>();
			if (rt == null) { rt = go.AddComponent<RectTransform>(); if (rt == null) World_command.Error(go.name, "not component"); }

			rt.transform.position = JP.TryGet<Vector3>("pos", rt.transform.position);
			rt.sizeDelta = JP.TryGet<Vector2>("size", rt.sizeDelta);
			rt.anchorMin = JP.TryGet<Vector2>("ancMin", rt.anchorMin);
			rt.anchorMax = JP.TryGet<Vector2>("ancMax", rt.anchorMax);
			rt.pivot = JP.TryGet<Vector2>("pivot", rt.pivot);
			rt.anchoredPosition = JP.TryGet<Vector2>("anchPos", rt.anchoredPosition);
			rt.rotation = JP.TryGet<Quaternion>("rot", rt.rotation);
		}
		if(json.TryGetValue("Img", out JP) && JP != null) {
			Image img = go.GetComponent<Image>();
			if (img == null) { img = go.AddComponent<Image>(); if (img == null) World_command.Error(go.name, "not component"); }

			img.sprite = JP.TryGet<Sprite>("sprite", img.sprite);
			img.color = JP.TryGet<Color>("color", img.color);
			img.type = JP.TryGet<Image.Type>("type", img.type);
			img.fillMethod = JP.TryGet<Image.FillMethod>("fm", img.fillMethod);
			img.fillOrigin = JP.TryGet<int>("fo", img.fillOrigin);
			img.fillAmount = JP.TryGet<float>("fa", img.fillAmount);
			img.preserveAspect = JP.TryGet<bool>("pa", img.preserveAspect);
			img.material = JP.TryGet<Material>("material", img.material);
			img.enabled = JP.TryGet<bool>("enabled", img.enabled);
		}
		if(json.TryGetValue("Text", out JP))
		{
			Text text = go.GetComponent<Text>();
			if (text == null) { text = go.AddComponent<Text>(); if (text == null) World_command.Error(go.name, "not component"); }

			text.text = JP.TryGet<string>("text", text.text);
			text.font = JP.TryGet<Font>("font", text.font);
			text.fontSize = JP.TryGet<int>("fontSize", text.fontSize);
			text.fontStyle = JP.TryGet<FontStyle>("fontStyle", text.fontStyle);
			text.color = JP.TryGet<Color>("color", text.color);
			text.alignment = JP.TryGet<TextAnchor>("aligment", text.alignment);
			text.horizontalOverflow = JP.TryGet<HorizontalWrapMode>("horOverflow", text.horizontalOverflow);
			text.verticalOverflow = JP.TryGet<VerticalWrapMode>("verOverflow", text.verticalOverflow);
			text.lineSpacing = JP.TryGet<float>("lineSpacing", text.lineSpacing);
			text.supportRichText = JP.TryGet<bool>("suppRichText", text.supportRichText);
			text.resizeTextForBestFit = JP.TryGet<bool>("resizeTextForBestFit", text.resizeTextForBestFit);
			text.resizeTextMaxSize = JP.TryGet<int>("resizeTextMaxSize", text.resizeTextMaxSize);
			text.resizeTextMinSize = JP.TryGet<int>("resizeTextMinSize", text.resizeTextMinSize);
			text.material = JP.TryGet<Material>("material", text.material);
			text.raycastTarget = JP.TryGet<bool>("raycTr", text.raycastTarget);
			text.enabled = JP.TryGet<bool>("enabled", text.enabled);
		}
		if(json.TryGetValue("RawImage", out JP))
		{
			RawImage rawi = go.GetComponent<RawImage>();
			if (rawi == null) { rawi = go.AddComponent<RawImage>(); if (rawi == null) World_command.Error(go.name, "not component"); }

			rawi.texture = JP.TryGet<Texture>("texture", rawi.texture);
			rawi.color = JP.TryGet<Color>("color", rawi.color);
			rawi.uvRect = JP.TryGet<Rect>("uvRect", rawi.uvRect);
			rawi.material = JP.TryGet<Material>("material", rawi.material);
			rawi.raycastTarget = JP.TryGet<bool>("raycT", rawi.raycastTarget);
			rawi.enabled = JP.TryGet<bool>("enabled", rawi.enabled);
		}
		if(json.TryGetValue("Mask", out JP))
		{
			Mask mask = go.GetComponent<Mask>();
			if (mask == null) { mask = go.AddComponent<Mask>(); if (mask == null) World_command.Error(go.name, "not component"); }

			mask.showMaskGraphic = JP.TryGet<bool>("showMaskGraphic", mask.showMaskGraphic);
			mask.enabled = JP.TryGet<bool>("enabled", mask.enabled);
		}
		if (json.TryGetValue("RectMask2D", out JP))
		{
			RectMask2D rectMask = go.GetComponent<RectMask2D>();
			if (rectMask == null) { rectMask = go.AddComponent<RectMask2D>(); if (rectMask == null) World_command.Error(go.name, "not component"); }

			rectMask.enabled = JP.TryGet<bool>("enabled", rectMask.enabled);
		}
		if (json.TryGetValue("Button", out JP))
		{
			Button button = go.GetComponent<Button>();
			if (button == null) { button = go.AddComponent<Button>(); if (button == null) World_command.Error(go.name, "not component"); }

			button.interactable = JP.TryGet<bool>("interactable", button.interactable);
			button.enabled = JP.TryGet<bool>("enabled", button.enabled);

			button.transition = JP.TryGet<Button.Transition>("transition", button.transition);
			button.colors = JP.TryGet<ColorBlock>("colors", button.colors);
			button.spriteState = JP.TryGet<SpriteState>("spriteState", button.spriteState);
			button.animationTriggers = JP.TryGet<AnimationTriggers>("animationTriggers", button.animationTriggers);
			button.navigation = JP.TryGet<Navigation>("navigation", button.navigation);
			button.targetGraphic = go.GetComponent<Graphic>();

			JsonP.JsonPActionClass onClickAction = JP.TryGet<JsonP.JsonPActionClass>("onClick", null);
			if (onClickAction != null) button.onClick.AddListener(onClickAction.JsonPAction);
		}
		if (json.TryGetValue("InputField", out JP))
		{
			InputField input = go.GetComponent<InputField>();
			if (input == null) { input = go.AddComponent<InputField>(); if (input == null) World_command.Error(go.name, "not component"); }

			input.interactable = JP.TryGet<bool>("interactable", input.interactable);
			input.enabled = JP.TryGet<bool>("enabled", input.enabled);

			input.text = JP.TryGet<string>("text", input.text);
			input.characterLimit = JP.TryGet<int>("characterLimit", input.characterLimit);
			input.readOnly = JP.TryGet<bool>("readOnly", input.readOnly);

			input.contentType = JP.TryGet<InputField.ContentType>("contentType", input.contentType);
			input.lineType = JP.TryGet<InputField.LineType>("lineType", input.lineType);
			input.inputType = JP.TryGet<InputField.InputType>("inputType", input.inputType);
			input.keyboardType = JP.TryGet<TouchScreenKeyboardType>("keyboardType", input.keyboardType);
			input.characterValidation = JP.TryGet<InputField.CharacterValidation>("characterValidation", input.characterValidation);

			input.caretBlinkRate = JP.TryGet<float>("caretBlinkRate", input.caretBlinkRate);
			input.caretColor = JP.TryGet<Color>("caretColor", input.caretColor);
			input.selectionColor = JP.TryGet<Color>("selectionColor", input.selectionColor);

			JsonP.JsonPActionTClass<string> onValueChangedAction = JP.TryGet<JsonP.JsonPActionTClass<string>>("onValueChanged", null);
			if (onValueChangedAction != null) input.onValueChanged.AddListener(val => onValueChangedAction.JsonPAction(val));

			JsonP.JsonPActionTClass<string> onEndEditAction = JP.TryGet<JsonP.JsonPActionTClass<string>>("onEndEdit", null);
			if (onEndEditAction != null) input.onEndEdit.AddListener((val) => onEndEditAction.JsonPAction(val));
		}
		if (json.TryGetValue("Toggle", out JP))
		{
			Toggle toggle = go.GetComponent<Toggle>();
			if (toggle == null) { toggle = go.AddComponent<Toggle>(); if (toggle == null) World_command.Error(go.name, "not component"); }

			toggle.interactable = JP.TryGet<bool>("interactable", toggle.interactable);
			toggle.enabled = JP.TryGet<bool>("enabled", toggle.enabled);
			toggle.isOn = JP.TryGet<bool>("isOn", toggle.isOn);

			toggle.transition = JP.TryGet<Selectable.Transition>("transition", toggle.transition);
			toggle.colors = JP.TryGet<ColorBlock>("colors", toggle.colors);
			toggle.spriteState = JP.TryGet<SpriteState>("spriteState", toggle.spriteState);
			toggle.animationTriggers = JP.TryGet<AnimationTriggers>("animationTriggers", toggle.animationTriggers);
			toggle.navigation = JP.TryGet<Navigation>("navigation", toggle.navigation);
			toggle.targetGraphic = go.GetComponent<Graphic>();

			JsonP.JsonPActionTClass<bool> onValueChangedAction = JP.TryGet<JsonP.JsonPActionTClass<bool>>("onValueChanged", null);
			if (onValueChangedAction != null)
			{
				toggle.onValueChanged.RemoveAllListeners();
				toggle.onValueChanged.AddListener((val) => onValueChangedAction.JsonPAction(val));
			}
		}
		if (json.TryGetValue("ToggleGroup", out JP))
		{
			ToggleGroup tg = go.GetComponent<ToggleGroup>();
			if (tg == null) { tg = go.AddComponent<ToggleGroup>(); if (tg == null) World_command.Error(go.name, "not component"); }

			tg.allowSwitchOff = JP.TryGet<bool>("allowSwitchOff", tg.allowSwitchOff);

			Toggle target = null;
			Dictionary<string, GameObject> groupDic;
			GameObject objToggle;
			if (dic.TryGetValue("ToggleGroup", out groupDic) && groupDic.TryGetValue("objToggle", out objToggle))
			{
				if (objToggle != null && objToggle.activeInHierarchy)
				{
					target = objToggle.GetComponent<Toggle>();
				}
			}

			if (target != null)
			{
				target.isOn = true;
			}
			else
			{
				World_command.Error(go.name, "Toggle not found or destroyed");
			}
		}
		if (json.TryGetValue("Slider", out JP))
		{
			Slider slider = go.GetComponent<Slider>();
			if (slider == null) { slider = go.AddComponent<Slider>(); if (slider == null) World_command.Error(go.name, "not component"); }

			slider.interactable = JP.TryGet<bool>("interactable", slider.interactable);
			slider.enabled = JP.TryGet<bool>("enabled", slider.enabled);

			slider.minValue = JP.TryGet<float>("minValue", slider.minValue);
			slider.maxValue = JP.TryGet<float>("maxValue", slider.maxValue);
			slider.value = JP.TryGet<float>("value", slider.value);

			slider.wholeNumbers = JP.TryGet<bool>("wholeNumbers", slider.wholeNumbers);
			slider.direction = JP.TryGet<Slider.Direction>("direction", slider.direction);

			slider.transition = JP.TryGet<Selectable.Transition>("transition", slider.transition);
			slider.colors = JP.TryGet<ColorBlock>("colors", slider.colors);
			slider.spriteState = JP.TryGet<SpriteState>("spriteState", slider.spriteState);
			slider.animationTriggers = JP.TryGet<AnimationTriggers>("animationTriggers", slider.animationTriggers);
			slider.navigation = JP.TryGet<Navigation>("navigation", slider.navigation);
			slider.targetGraphic = go.GetComponent<Graphic>();

			JsonP.JsonPActionTClass<float> onValueChangedAction = JP.TryGet<JsonP.JsonPActionTClass<float>>("onValueChanged", null);
			if (onValueChangedAction != null)
			{
				slider.onValueChanged.RemoveAllListeners();
				slider.onValueChanged.AddListener((val) => onValueChangedAction.JsonPAction(val));
			}
		}
		if (json.TryGetValue("Scrollbar", out JP))
		{
			Scrollbar scrollbar = go.GetComponent<Scrollbar>();
			if (scrollbar == null) { scrollbar = go.AddComponent<Scrollbar>(); if (scrollbar == null) World_command.Error(go.name, "not component"); }

			scrollbar.interactable = JP.TryGet<bool>("interactable", scrollbar.interactable);
			scrollbar.enabled = JP.TryGet<bool>("enabled", scrollbar.enabled);

			scrollbar.size = JP.TryGet<float>("size", scrollbar.size);
			scrollbar.value = JP.TryGet<float>("value", scrollbar.value);
			scrollbar.direction = JP.TryGet<Scrollbar.Direction>("direction", scrollbar.direction);

			scrollbar.transition = JP.TryGet<Selectable.Transition>("transition", scrollbar.transition);
			scrollbar.colors = JP.TryGet<ColorBlock>("colors", scrollbar.colors);
			scrollbar.spriteState = JP.TryGet<SpriteState>("spriteState", scrollbar.spriteState);
			scrollbar.animationTriggers = JP.TryGet<AnimationTriggers>("animationTriggers", scrollbar.animationTriggers);
			scrollbar.navigation = JP.TryGet<Navigation>("navigation", scrollbar.navigation);
			scrollbar.targetGraphic = go.GetComponent<Graphic>();

			JsonP.JsonPActionTClass<float> onValueChangedAction = JP.TryGet<JsonP.JsonPActionTClass<float>>("onValueChanged", null);
			if (onValueChangedAction != null)
			{
				scrollbar.onValueChanged.RemoveAllListeners();
				scrollbar.onValueChanged.AddListener((val) => onValueChangedAction.JsonPAction(val));
			}
		}
		if (json.TryGetValue("Dropdown", out JP))
		{
			Dropdown dropdown = go.GetComponent<Dropdown>();
			if (dropdown == null) { dropdown = go.AddComponent<Dropdown>(); if (dropdown == null) World_command.Error(go.name, "not component"); }

			dropdown.interactable = JP.TryGet<bool>("interactable", dropdown.interactable);
			dropdown.enabled = JP.TryGet<bool>("enabled", dropdown.enabled);

			int selectedIndex = JP.TryGet<int>("selectedIndex", dropdown.value);
			if (selectedIndex < 0) selectedIndex = 0;

			var options = JP.TryGet<List<string>>("options", null);
			if (options != null)
			{
				dropdown.ClearOptions();
				dropdown.AddOptions(options);

				if (selectedIndex >= 0 && selectedIndex < dropdown.options.Count)
				{
					dropdown.value = selectedIndex;
				}
				else if (dropdown.options.Count > 0)
				{
					dropdown.value = 0;
				}
			}
			else
			{
				if (selectedIndex >= 0 && selectedIndex < dropdown.options.Count)
				{
					dropdown.value = selectedIndex;
				}
			}

			dropdown.transition = JP.TryGet<Selectable.Transition>("transition", dropdown.transition);
			dropdown.colors = JP.TryGet<ColorBlock>("colors", dropdown.colors);
			dropdown.spriteState = JP.TryGet<SpriteState>("spriteState", dropdown.spriteState);
			dropdown.animationTriggers = JP.TryGet<AnimationTriggers>("animationTriggers", dropdown.animationTriggers);
			dropdown.navigation = JP.TryGet<Navigation>("navigation", dropdown.navigation);
			dropdown.targetGraphic = go.GetComponent<Graphic>();

			JsonP.JsonPActionTClass<int> onValueChangedAction = JP.TryGet<JsonP.JsonPActionTClass<int>>("onValueChanged", null);
			if (onValueChangedAction != null)
			{
				dropdown.onValueChanged.RemoveAllListeners();
				dropdown.onValueChanged.AddListener((val) => onValueChangedAction.JsonPAction(val));
			}
		}
		if (json.TryGetValue("ScrollRect", out JP))
		{
			ScrollRect sr = go.GetComponent<ScrollRect>();
			if (sr == null) { sr = go.AddComponent<ScrollRect>(); if (sr == null) World_command.Error(go.name, "not component"); }

			sr.enabled = JP.TryGet<bool>("enabled", sr.enabled);
			sr.elasticity = JP.TryGet<float>("elasticity", sr.elasticity);
			sr.inertia = JP.TryGet<bool>("inertia", sr.inertia);
			sr.decelerationRate = JP.TryGet<float>("decelerationRate", sr.decelerationRate);

			sr.horizontal = JP.TryGet<bool>("horizontal", sr.horizontal);
			sr.vertical = JP.TryGet<bool>("vertical", sr.vertical);

			sr.content = JP.TryGet<RectTransform>("content", sr.content);

			Transform t = dic.ContainsKey("ScrollRect") && dic["ScrollRect"].ContainsKey("contentName") ? dic["ScrollRect"]["contentName"].transform : null;
			if (t != null) sr.content = t as RectTransform;
			else World_command.Error(go.name, "Content not found");

			Transform t2 = dic.ContainsKey("ScrollRect") && dic["ScrollRect"].ContainsKey("hScrollName") ? dic["ScrollRect"]["hScrollName"].transform : null;
			if (t2 != null) sr.horizontalScrollbar = t2.GetComponent<Scrollbar>();

			Transform t3 = dic.ContainsKey("ScrollRect") && dic["ScrollRect"].ContainsKey("vScrollName") ? dic["ScrollRect"]["vScrollName"].transform : null;
			if (t3 != null) sr.verticalScrollbar = t3.GetComponent<Scrollbar>();

			sr.viewport = JP.TryGet<RectTransform>("viewport", sr.viewport);

			Transform t4 = dic.ContainsKey("ScrollRect") && dic["ScrollRect"].ContainsKey("viewportName") ? dic["ScrollRect"]["viewportName"].transform : null;
			if (t4 != null) sr.viewport = t4 as RectTransform;

			JsonP.JsonPActionTClass<Vector2> onValueChangedAction = JP.TryGet<JsonP.JsonPActionTClass<Vector2>>("onValueChanged", null);
			if (onValueChangedAction != null)
			{
				sr.onValueChanged.RemoveAllListeners();
				sr.onValueChanged.AddListener((val) => onValueChangedAction.JsonPAction(val));
			}
		}
		if(json.TryGetValue("Destroy", out ls))
		{
			foreach(string st in ls)
			{
				if(st != null && destroyType.ContainsKey(st))
				{
					var comp = go.GetComponents(destroyType[st]);
					foreach(var com in comp)
					{
						if(com != null)
						{
							UnityEngine.Object.Destroy(com);
						}
					}
				}
			}
		}
	}

	public ManagerGuiCr(GameObject go)
	{
		if (go.GetComponent<RectTransform>() == null) World_command.Error("ManagerGuiCr", "parametrs == null");
		Go = go;
	}

	public void ReGameObject(GameObject go)
	{
		if (go.GetComponent<RectTransform>() == null) World_command.Error("ManagerGuiCr", "parametrs == null");
		Go = go;
		foreach(ManagerGuiCr mc in mgc.Values)
		{
			mc.Go = WorldGoDisasamble.Assemble(mc.wd, Go.GetComponent<RectTransform>());
			mc.ReGameObject(mc.Go);
		}
	}

	public void JsonPManagerGuiCr(string jsonP)
	{
		if (!JsonP.IsValidJson(jsonP)) return;
		JsonP jp = new JsonP(jsonP);

		JsonP s;
		string sname;
		string[] slpath;
		if (jp.TryGetValue<JsonP>("add", out s)) {
			sname = s.TryGet<string>("name");
			slpath = s.TryGet<string[]>("path");

			GameObject go = new GameObject(sname); go.AddComponent<RectTransform>(); Add(go, sname, new List<string>(slpath));
		}
		if (jp.TryGetValue<JsonP>("del", out s)) {
			sname = s.TryGet<string>("name");
			slpath = s.TryGet<string[]>("path");

			Delete(sname, new List<string>(slpath));
		}
		if(jp.TryGetValue<JsonP>("comp", out s)) {
			sname = s.TryGet<string>("name");
			slpath = s.TryGet<string[]>("path");
			string jsp = s.TryGet<string>("jsonP");
			string jspGo = s.TryGet<string>("lincGo");

			ManagerComponent(sname, new List<string>(slpath), jsp, jspGo);
		}
	}

	public void Add(GameObject go, string name, List<string> lpathGui)
	{
		if (go == null || name == "" || lpathGui == null || go.GetComponent<RectTransform>() == null) World_command.Error("ManagerGuiCr", "parametrs == null");
		List<string> lp = new List<string>(lpathGui);

		ManagerGuiCr mgcd;
		if (lp.Count != 0)
		{
			if (!mgc.TryGetValue(lp[lp.Count - 1], out mgcd)) World_command.Error(go.name, "Not path");
			lp.RemoveAt(lp.Count - 1);
			mgcd.Add(go, name, lp);
		}
		else
		{
			if (mgc.ContainsKey(name)) World_command.Error(go.name, "created Activity Obg");
			mgc.Add(name, new ManagerGuiCr(UnityEngine.Object.Instantiate(go, Go.GetComponent<RectTransform>())));
			mgc[name].wd = WorldGoDisasamble.Disassemble(mgc[name].Go);
		}
	}

	public GameObject Get(string name, List<string> lpathGui)
	{
		if (name == "" || lpathGui == null) World_command.Error("ManagerGuiCr", "parametrs == null");
		List<string> lp = new List<string>(lpathGui);

		ManagerGuiCr mgcd;
		if (lp.Count != 0)
		{
			if (!mgc.TryGetValue(lp[lp.Count - 1], out mgcd)) World_command.Error(name, "Not path");
			lp.RemoveAt(lp.Count - 1);
			return mgcd.Get(name, lp);
		}
		else
		{
			if (!mgc.TryGetValue(name, out mgcd)) World_command.Error(name, "Not Obg on Gui Manager");
			return mgcd.Go;
		}
	}

	public GameObject TryGet(string name, List<string> lpathGui)
	{
		if (name == "" || lpathGui == null) return null;
		List<string> lp = new List<string>(lpathGui);

		ManagerGuiCr mgcd;
		if (lp.Count != 0)
		{
			if (!mgc.TryGetValue(lp[lp.Count - 1], out mgcd)) return null;
			lp.RemoveAt(lp.Count - 1);
			return mgcd.TryGet(name, lp);
		}
		else
		{
			if (!mgc.TryGetValue(name, out mgcd)) return null;
			return mgcd.Go;
		}
	}

	public void Save(string name, List<string> lpathGui)
	{
		if (name == "" || lpathGui == null) World_command.Error("ManagerGuiCr", "parametrs == null");
		List<string> lp = new List<string>(lpathGui);

		ManagerGuiCr mgcd;
		if (lp.Count != 0)
		{
			if (!mgc.TryGetValue(lp[lp.Count - 1], out mgcd)) World_command.Error(name, "Not path");
			lp.RemoveAt(lp.Count - 1);
			mgcd.Save(name, lp);
		}
		else
		{
			if (!mgc.TryGetValue(name, out mgcd)) World_command.Error(name, "Not Obg on Gui Manager");
			mgcd.wd = WorldGoDisasamble.Disassemble(mgcd.Go);
		}
	}

	public void Delete(string name, List<string> lpathGui)
	{
		if (name == "" || lpathGui == null) World_command.Error("ManagerGuiCr", "parametrs == null");
		List<string> lp = new List<string>(lpathGui);

		ManagerGuiCr mgcd;
		if (lp.Count != 0)
		{
			if (!mgc.TryGetValue(lp[lp.Count - 1], out mgcd)) World_command.Error(name, "Not path");
			lp.RemoveAt(lp.Count - 1);
			mgcd.Delete(name, lp);
		}
		else
		{
			if (!mgc.Remove(name)) World_command.Error(name, "Not Obg on Gui Manager");
		}
	}

	public void ManagerComponent(string name, List<string> lpathGui, string jsonP, string jsonPGoPathLinc)
	{
		Dictionary<string, Dictionary<string, GameObject>> dic = new Dictionary<string, Dictionary<string, GameObject>>();
		if (JsonP.IsValidJson(jsonPGoPathLinc))
		{
			JsonP jp = new JsonP(jsonPGoPathLinc);
			foreach(var i in jp.GetCopyDicJsonP<JsonP>())
			{
				foreach(var j in i.Value.GetCopyDicJsonP<DicConv.KeyValuePairCl<string, List<string>>>())
				{
					if (!dic.ContainsKey(i.Key)) dic.Add(i.Key, new Dictionary<string, GameObject>());
					if (!dic[i.Key].ContainsKey(j.Key)) dic[i.Key].Add(j.Key, null);
					dic[i.Key][j.Key] = TryGet(j.Value.Key, j.Value.Value);
				}
			}
		}
		AssambleJsonUiObject(Get(name, lpathGui), jsonP, dic);
	}
}