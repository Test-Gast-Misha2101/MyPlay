﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class ControllerButton : MonoBehaviour {
	private bool visiable = false;

	private Dictionary<bool, Dictionary<KeyCode, Action>> KeyFunc;
	private static HashSet<KeyCode> BlockKeys = new HashSet<KeyCode>() { KeyCode.Escape };

	void Awake()
	{
		KeyFunc = new Dictionary<bool, Dictionary<KeyCode, Action>>() {
			{true, new Dictionary<KeyCode, Action>() {
				{ KeyCode.Tab, FTab}
			}},
			{false, new Dictionary<KeyCode, Action>() {
				{ KeyCode.Tab, FTab }
			}}
		};
	}

	private void FTab()
	{
		visiable = !visiable;
	}

	public static void BlockKey(KeyCode key)
	{
		BlockKeys.Add(key);
	}

	public static void UnBlockKey(KeyCode key)
	{
		if (key == KeyCode.Escape) return;
		BlockKeys.Remove(key);
	}

	void Update () {
		Dictionary<KeyCode, Action> cur;
		if (!KeyFunc.TryGetValue(visiable, out cur)) return;

		foreach(var key in cur.Keys)
		{
			if(Input.GetKeyDown(key) && cur[key] != null)
			{
				cur[key]();
			}
		}
	}

	void LateUpdate()
	{
		foreach (var key in BlockKeys)
		{
			Input.GetKeyDown(key);
		}
		Cursor.lockState = visiable ? CursorLockMode.None : CursorLockMode.Locked;
		Cursor.visible = visiable;
	}
}
