﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BaseDate {
	public class BaseDateOre {
		private static readonly Dictionary<string, New_ore> Ores = new Dictionary<string, New_ore>() {
			{"Flammogidrid", new Flammogidrid()},
		};

		public static bool ConstantsOres(string en)
		{
			return Ores.ContainsKey(en);
		}

		public static List<string> GetListOresName() { return new List<string>(Ores.Keys); }

		public static New_ore GetObjOre(string store_Type)
		{
			New_ore new_Ore;
			Ores.TryGetValue(store_Type, out new_Ore);
			return new_Ore;
		}

		public static void CreateNewObjOre(GameObject error, string ore_Type, New_ore new_Ore)
		{
			if (error == null || new_Ore == null) World_command.Error(error.name, "Null in created");
			if (new_Ore.Name() == "Null" || Ores.ContainsKey(ore_Type) || Ores.ContainsKey(new_Ore.Name())) World_command.Error(error.name, "Created Ore Name in [this Name]");
			Ores.Add(ore_Type, new_Ore);
		}
	}
}