import os
from pathlib import Path

def collect_all_cs_into_one_txt():
    root_dir = Path('.').resolve()
    output_file = root_dir / 'all_code.txt'
    
    collected_lines = []
    file_count = 0

    # Проходим по всем .cs файлам рекурсивно
    for cs_path in sorted(root_dir.rglob('*.cs')):
        if not cs_path.is_file():
            continue
        
        file_count += 1
        
        # Добавляем разделитель с именем файла (чтобы было понятно, где какой файл)
        collected_lines.append(f"{'='*60}")
        collected_lines.append(f"FILE: {cs_path.relative_to(root_dir)}")
        collected_lines.append(f"{'='*60}")
        
        try:
            content = cs_path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            # Если вдруг кодировка не UTF-8 — пробуем latin-1, чтобы не терять файлы
            content = cs_path.read_text(encoding='latin-1')
        
        # Сохраняем все отступы, переносы строк и форматирование
        collected_lines.append(content)
        # Добавим пустую строку после каждого файла для читаемости
        collected_lines.append("")

    # Записываем всё в один файл
    full_content = "\n".join(collected_lines)
    output_file.write_text(full_content, encoding='utf-8')
    
    print(f"Готово! Обработано файлов: {file_count}")
    print(f"Результат сохранён в: {output_file}")

if __name__ == '__main__':
    collect_all_cs_into_one_txt()
