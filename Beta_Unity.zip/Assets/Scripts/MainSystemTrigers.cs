﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainSystemTrigers : MonoBehaviour {
	private static List<Triger> ClTr = new List<Triger>();
	private static List<trig> trigs = new List<trig>();

	public enum trig
	{
		Restart,
		Update_Block
	}

	public static bool TestTrig(trig trTest, trig trif)
	{
		return trTest == trif || trTest == trig.Restart;
	}

	public static bool TestTrig(trig tr, HashSet<trig> ltr)
	{
		foreach(trig tr1 in ltr)
		{
			if(tr1 == tr || tr1 == trig.Restart)
			{
				return true;
			}
		}
		return false;
	}

	public static void ResetClTr()
	{
		ClTr = new List<Triger>(FindObjectsOfType<Triger>());
	}

	public static void RegistTrig(trig tr)
	{
		trigs.Add(tr);
	}

	void Awake()
	{
		ResetClTr();
	}

	void FixedUpdate()
	{
		if(trigs.Count > 0)
		{
			var ll = new List<trig>(trigs);

			foreach (var l in ll) {
				trig tri = trigs[trigs.Count - 1];
				trigs.RemoveAt(trigs.Count - 1);
				foreach (Triger tr in ClTr)
				{
					tr.Trigers(tri);
				}
			}
		}
	}
}
