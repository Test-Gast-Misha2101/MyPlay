﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Move_class : World_class_move
{
    [SerializeField] private Vector3 myBox = Vector3.one;
    [SerializeField] private List<Date_two_list> input_ore = new List<Date_two_list>();
    [SerializeField] private List<Date_two_list> output_ore = new List<Date_two_list>();

    [SerializeField] private List<GameObject> gam_inp = new List<GameObject>();
    [SerializeField] private List<GameObject> gam_out = new List<GameObject>();
    private Dictionary<World_command.Napr, List<List<Vector3>>> MyCoords = new Dictionary<World_command.Napr, List<List<Vector3>>>();
    private IF_move_functional iF_Move_Functional;

    public override Vector3 GetSize()
    {
        return myBox;
    }

    void Awake()
    {
        iF_Move_Functional = gameObject.GetComponent<IF_move_functional>();
        if (iF_Move_Functional == null)
            World_command.Error(gameObject.name, "not exemplar class IF_move_functional on this obgect");
    }

    public override List<Date_two_list> get_napr(Vector3 vec)
    {
        return output_ore;
    }

    protected override bool AwTestError()
    {
        return myBox.x > 0 && myBox.y > 0 && myBox.z > 0;
    }

    protected override bool UpTestError()
    {
        var inputSet = new HashSet<CoordKey>();
        foreach (var i in input_ore)
        {
            var key = new CoordKey(i.x, i.y, i.napr);
            if (!inputSet.Add(key))
                return false;
        }

        var outputSet = new HashSet<CoordKey>();
        foreach (var o in output_ore)
        {
            var key = new CoordKey(o.x, o.y, o.napr);
            if (!outputSet.Add(key))
                return false;

            if (inputSet.Contains(key))
                return false;
        }

        return true;
    }

    public override bool test_napr_get(GameObject g, World_command.Date_move dm)
    {
        var nap = World_command.GetSideFacing(gameObject.transform, g.transform.position);
        var dtl = dm == World_command.Date_move.INPUT ? input_ore : output_ore;

        foreach (var v in dtl)
        {
            if (v.napr == nap)
            {
                return true;
            }
        }

        return false;
    }

    private List<GameObject> GetObjectsAtCell(List<GameObject> g, World_command.Date_move dm)
    {
        List<GameObject> gm = new List<GameObject>();
        foreach (GameObject gmo in g)
        {
            if (gmo != null && gmo != gameObject)
            {
                World_class_move wcm = gmo.GetComponent<World_class_move>();
                if (wcm != null && wcm.test_napr_get(gameObject, dm))
                    gm.Add(gmo);
            }
        }
        return gm;
    }

    public override void Trigers(MainSystemTrigers.trig tr)
    {
        if (!MainSystemTrigers.TestTrig(tr, MainSystemTrigers.trig.Update_Block))
            return;

        MyCoords = World_command.GetSurfaceCoordsBySide(gameObject, myBox);

        gam_inp.Clear();
        gam_out.Clear();

        foreach (var dtl in input_ore)
        {
            if (!MyCoords.ContainsKey(dtl.napr)) continue;
            if (dtl.y >= MyCoords[dtl.napr].Count || dtl.x >= MyCoords[dtl.napr][dtl.y].Count) continue;

            Vector3 cellPos = MyCoords[dtl.napr][dtl.y][dtl.x];
            List<GameObject> nearby = Config.Get_obg_sceneGo(cellPos, DicVec.Generated.Player_Block);
            if (nearby == null || nearby.Count == 0) { continue; }
            nearby = GetObjectsAtCell(nearby, World_command.Date_move.OUTPUT);
            if (nearby == null || nearby.Count == 0) { continue; }
            gam_inp.AddRange(nearby);
        }

        foreach (var dtl in output_ore)
        {
            if (!MyCoords.ContainsKey(dtl.napr)) continue;
            if (dtl.y >= MyCoords[dtl.napr].Count || dtl.x >= MyCoords[dtl.napr][dtl.y].Count) continue;

            Vector3 cellPos = MyCoords[dtl.napr][dtl.y][dtl.x];
            List<GameObject> nearby = Config.Get_obg_sceneGo(cellPos, DicVec.Generated.Player_Block);
            if (nearby == null || nearby.Count == 0) { continue; }
            nearby = GetObjectsAtCell(nearby, World_command.Date_move.INPUT);
            if (nearby == null || nearby.Count == 0) { continue; }
            gam_out.AddRange(nearby);
        }
    }

    public override string get_ore(GameObject po)
    {
        if (po == null || output_ore.Count == 0)
            return ORE_BLOCKS.Null;

        foreach (var n in output_ore)
        {
            if (!MyCoords.ContainsKey(n.napr)) continue;
            if (n.y >= MyCoords[n.napr].Count || n.x >= MyCoords[n.napr][n.y].Count) continue;

            Vector3 cellPos = MyCoords[n.napr][n.y][n.x];
            if (Vector3.Distance(po.transform.position, cellPos) <= 0.1f && po.GetComponent<World_class_move>() != null && gam_out.Contains(po))
            {
                return iF_Move_Functional.move_ore();
            }
        }

        return ORE_BLOCKS.Null;
    }

    void Update()
    {
        iF_Move_Functional.Up_Func_Ore(gam_inp, gam_out);
    }


    void OnDestroy()
    {
        Config.Destroy_obj_size_scene(gameObject, DicVec.Generated.Player_Block);
    }
}