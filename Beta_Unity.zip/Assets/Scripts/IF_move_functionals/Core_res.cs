﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Conveir))]
public class Core_res : IF_move_functional
{
    public Camera MainCam { get; set; }

    private Dictionary<string, int> dic = new Dictionary<string, int>();

    void Awake()
    {
        foreach (string orel in BaseDate.BaseDateOre.GetListOresName())
        {
            if (orel != ORE_BLOCKS.Null)
                dic.Add(orel, 0);
        }
    }

    public override void Up_Func_Ore(List<GameObject> gam_inp, List<GameObject> gam_out)
    {
        List<string> ls = BaseDate.BaseDateOre.GetListOresName();
        foreach (var s in ls)
        {
            if (!dic.ContainsKey(s))
            {
                dic[s] = 0;
            }
        }

        if (gam_inp.Count > 0)
        {
            foreach (var obj in gam_inp)
            {
                var comps = obj.GetComponents<World_class_move>();
                foreach (var c in comps)
                {
                    if (c != null)
                    {
                        var ore = c.get_ore(gameObject);
                        if (ore != ORE_BLOCKS.Null && dic.ContainsKey(ore))
                        {
                            dic[ore] += 1;
                            return;
                        }
                    }
                }
            }
        }
    }

    public override string move_ore()
    {
        return ORE_BLOCKS.Null;
    }

    public override string get_ore_entity(GameObject entity, string ore, int len_ore = 1)
    {
        if (entity.tag == "Player" && dic[ore] - len_ore >= 0)
        {
            dic[ore] -= len_ore;
            return ore;
        }
        return ORE_BLOCKS.Null;
    }
}
