﻿using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[RequireComponent(typeof(Conveir))]
public class Mine_ore : IF_move_functional
{
	[Header("Toplivo")]
	[SerializeField, Delayed] private List<string> toplivo_white_list = new List<string>();
	private List<string> toplivo = new List<string>();
	[Header("Mine_Ore")]
	[SerializeField, Delayed] private float mine_ore = 1;
	[SerializeField, Delayed] private List<string> ore_type;
	[Header("Ore")]
	private int len_block = 1;
	[SerializeField, Delayed] private int max_len_ore = 15;
	[SerializeField, Delayed] private int max_len_interface = 15;
	[SerializeField, Delayed] private List<string> lore = new List<string>();

	private Vector3 myBox = Vector3.one;
	[SerializeField] private List<GameObject> gam = new List<GameObject>();

	private bool Test_toplivo(string ore)
	{
		return !ORE_BLOCKS.IfNullOre(ore) && BaseDate.BaseDateOre.GetObjOre(ore).FireToplivo();
	}

	protected override bool UpTestError()
	{
		return World_command.ProcessObjects<string, string>(toplivo_white_list, Test_toplivo).Count == toplivo_white_list.Count;
	}

	void Start()
	{
		len_block = Mathf.Max(1, Mathf.FloorToInt(myBox.x * myBox.y * myBox.z));
		StartCoroutine(corut_cr());
	}

	public override void Trigers(MainSystemTrigers.trig tr)
	{
		if (!MainSystemTrigers.TestTrig(tr, MainSystemTrigers.trig.Update_Block))
			return;
		if (ore_type.Count == 0)
			World_command.Error(gameObject.name, "error not var ore_type.Count == 0");
		gam.Clear();
		gam.AddRange(ORE_BLOCKS.GetOreInMy(gameObject, ore_type));
	}

	public override void Up_Func_Ore(List<GameObject> gam_inp, List<GameObject> gam_out)
	{
		if (ore_type.Count == 0)
			World_command.Error(gameObject.name, "error not var ore_type.Count == 0");
		if (gam.Count == 0)
			return;
		if (mine_ore == 0 || len_block == 0)
			World_command.Error(gameObject.name, "error not var mine_ore == 0 || len_block == 0");
		if (lore.Count >= max_len_ore && lore.Count != 0)
			return;
		if (gam_inp.Count != 0)
		{
			if (toplivo.Count > max_len_interface && toplivo.Count != 0)
				toplivo.Remove(lore[-1]);
			if (toplivo.Count >= max_len_ore)
				return;
			int idx = UnityEngine.Random.Range(0, gam_inp.Count);
			World_class_move[] conv = gam_inp[idx].GetComponents<World_class_move>();

			if (conv.Length != 0)
			{
				string orbl = conv[UnityEngine.Random.Range(0, conv.Length)].get_ore(gameObject);
				if (!ORE_BLOCKS.IfNullOre(orbl) && toplivo.Contains(orbl) && BaseDate.BaseDateOre.GetObjOre(orbl).FireToplivo())
				{
					toplivo.Add(orbl);
				}
			}
		}
	}

	private IEnumerator corut_cr()
	{
		Ore ore;
		while (true)
		{
			yield return new WaitForSeconds(0.01f);
			if (gam.Count == 0 || mine_ore / len_block == 0 || (mine_ore / len_block) * gam.Count == 0) continue;
			for (float i = 1 / ((mine_ore / len_block) * gam.Count); i > 0; i -= 0.01f)
			{
				yield return new WaitForSeconds(0.01f);
			}
			if (lore.Count < max_len_ore)
			{
				if (gam.Count > 0)
				{
					foreach (GameObject g in gam)
					{
						ore = g.GetComponent<Ore>();
						if (ore != null && BaseDate.BaseDateOre.ConstantsOres(ore.ore))
						{
							lore.Add(ore.ore);
							break;
						}
					}
				}
			}
		}
	}

	public override string move_ore()
	{
		if (lore.Count > 0)
		{
			string ort = lore[lore.Count - 1];
			lore.RemoveAt(lore.Count - 1);
			return ort;
		}
		return ORE_BLOCKS.Null;
	}

	public override string get_ore_entity(GameObject entity, string ore, int len_ore = 1)
	{
		return ORE_BLOCKS.Null;
	}
}