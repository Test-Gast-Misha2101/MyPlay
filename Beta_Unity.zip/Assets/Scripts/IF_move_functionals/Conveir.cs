﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Move_class))]
public class Conveir : IF_move_functional
{
    [SerializeField, Delayed] private string res1 = ORE_BLOCKS.Null;
    [SerializeField, Delayed] private string res2 = ORE_BLOCKS.Null;
    [SerializeField, Delayed] private string res3 = ORE_BLOCKS.Null;

    public override void Up_Func_Ore(List<GameObject> gam_inp, List<GameObject> gam_out)
    {
        if (res1 != ORE_BLOCKS.Null)
        {
            if (res2 == ORE_BLOCKS.Null)
            {
                res2 = res1;
                res1 = ORE_BLOCKS.Null;
            }
        }

        if (res2 != ORE_BLOCKS.Null)
        {
            if (res3 == ORE_BLOCKS.Null)
            {
                res3 = res2;
                res2 = ORE_BLOCKS.Null;
            }
        }

        if (res1 == ORE_BLOCKS.Null && gam_inp.Count > 0)
        {
            foreach (var obj in gam_inp)
            {
                if (obj != null)
                {
                    var comps = obj.GetComponents<World_class_move>();
                    foreach (var c in comps)
                    {
                        if (c != null && res1 == ORE_BLOCKS.Null)
                        {
                            var ore = c.get_ore(gameObject);
                            if (ore != ORE_BLOCKS.Null)
                            {
                                res1 = ore;
                                return;
                            }
                        }
                    }
                }
            }
        }
    }

    public override string move_ore()
    {
        var r = res3;
        res3 = ORE_BLOCKS.Null;
        return r;
    }

    public override string get_ore_entity(GameObject entity, string ore, int len_ore = 1)
    {
        return ORE_BLOCKS.Null;
    }
}
