﻿using System.Collections.Generic;
using System;
using UnityEngine;
using System.Collections;
using System.Runtime.InteropServices;
using System.Linq;

public class BigStringAttribute : PropertyAttribute
{
	public int minLines;
	public int maxLines;

	public BigStringAttribute(int minLines = 3, int maxLines = 10)
	{
		this.minLines = minLines;
		this.maxLines = maxLines;
	}
}

public struct Vector3Int
{
	private int xi, yi, zi;
	public int xInt { get { return xi; } }
	public int yInt { get { return yi; } }
	public int zInt { get { return zi; } }
	public float x { get { return xi - 0.5f; } }
	public float y { get { return yi; } }
	public float z { get { return zi - 0.5f; } }

	public Vector3Int(float x, float y, float z) { this.xi = (int)(Mathf.Floor(x) + 1); this.yi = (int)(Mathf.Floor(y)); this.zi = (int)(Mathf.Floor(z) + 1); }
	public Vector3Int(Vector3 vec) { this.xi = (int)(Mathf.Floor(vec.x) + 1); this.yi = (int)(Mathf.Floor(vec.y)); this.zi = (int)(Mathf.Floor(vec.z) + 1); }

	public static Vector3Int operator +(Vector3Int a, Vector3Int b) { return new Vector3Int(a.xInt + b.xInt, a.yInt + b.yInt, a.zInt + b.zInt); }

	public override bool Equals(object obj)
	{
		if (obj == null)
			return false;

		if (!(obj is Vector3Int))
			return false;

		Vector3Int v = (Vector3Int)obj;
		return xi == v.xInt && yi == v.yInt && zi == v.zInt;
	}

	public override int GetHashCode()
	{
		unchecked
		{
			int hx = xi;
			int hy = yi;
			int hz = zi;
			return hx * 73856093 ^ hy * 19349663 ^ hz * 83492791;
		}
	}

	public override string ToString()
	{
		return "(" + x.ToString() + ", " + y.ToString() + ", " + z.ToString() + ")";
	}

	public Vector3 ToVector3()
	{
		return new Vector3(x, y, z);
	}
}

public class DicVec
{
	private readonly float cellSize;
	private readonly Vector3 gridOrigin = new Vector3(0.5f, 0.5f, 0.5f);

	public interface TypeGenerated { DicVec.Generated GetTypeGenerated(); }
	public enum Generated
	{
		Player_Block,
		Mine_blick
	}

	[System.Serializable]
	public struct GamePlayerBuildBlock
	{
		public GameObject go;
		public Prefab_Go sattings;
		public GameObject child;
		public GamePlayerBuildBlock(GameObject go, Prefab_Go sattings, GameObject child)
		{
			this.go = go;
			this.sattings = sattings;
			this.child = child;
		}
	}

	[System.Serializable]
	public struct GameInfo
	{
		public GameObject go;
		public TypeGenerated typeGenerated;
		public GameInfo(GameObject go, TypeGenerated typeGenerated)
		{
			this.go = go;
			this.typeGenerated = typeGenerated;
		}
	}

	private Dictionary<Generated, Dictionary<Vector3Int, List<GameInfo>>> cells = new Dictionary<Generated, Dictionary<Vector3Int, List<GameInfo>>>();

	private List<GameInfo> reuseList = new List<GameInfo>();

	public DicVec(float cellSize = 1f)
	{
		this.cellSize = cellSize;
	}

	private Vector3Int GetCell(Vector3 pos)
	{
		return new Vector3Int(
			(pos.x - gridOrigin.x) / cellSize,
			(pos.y - gridOrigin.y) / cellSize,
			(pos.z - gridOrigin.z) / cellSize
		);
	}

	private Dictionary<Vector3Int, List<GameInfo>> nu;

	private void gen_test(Generated generated)
	{
		if (!cells.TryGetValue(generated, out nu))
		{
			cells.Add(generated, new Dictionary<Vector3Int, List<GameInfo>>());
		}
	}

	public bool TestCreateBlock(Vector3 vec, TypeGenerated sattings)
	{
		var cell = GetCell(vec);
		List<GameInfo> list;

		if (vec == null || sattings == null)
		{
			World_command.Error("TestCrBl", "not date");
			return false;
		}
		Generated generated = sattings.GetTypeGenerated();
		gen_test(generated);
		if (cells[generated].TryGetValue(cell, out list))
		{
			if (list.Count == 0) return true;
		}
		else
		{
			return true;
		}
		return false;
	}

	public void Add(GameObject go, Vector3 vec, TypeGenerated sattings)
	{
		var cell = GetCell(vec);
		List<GameInfo> list;

		if (vec == null || sattings == null)
		{
			World_command.Error("TestCrBl", "not date");
			return;
		}
		Generated generated = sattings.GetTypeGenerated();
		gen_test(generated);

		if (!cells[generated].TryGetValue(cell, out list))
		{
			list = new List<GameInfo>();
			cells[generated][cell] = list;
		}
		cells[generated][cell].Add(new GameInfo(go, sattings));
	}

	private GameObject g(GameInfo gi)
	{
		return gi.go;
	}

	public void Remove(GameObject obj, Vector3 vec, Generated generated)
	{
		if (obj == null) return;
		var cell = GetCell(vec);
		gen_test(generated);
		if (cells[generated] == null || cells[generated].Count == 0 || !cells[generated].ContainsKey(cell)) return;

		for (int i = cells[generated][cell].Count - 1; i >= 0; i--)
		{
			if (cells[generated][cell][i].go == obj)
			{
				cells[generated][cell].RemoveAt(i);
			}
		}
	}

	public void RemoveInBox(Vector3 center, float halfSize, Generated generated)
	{
		var centerCell = GetCell(center);
		float cellRadius = halfSize / cellSize + 1;
		List<GameInfo> list;

		gen_test(generated);

		for (float x = -cellRadius; x <= cellRadius; ++x)
			for (float y = -cellRadius; y <= cellRadius; ++y)
				for (float z = -cellRadius; z <= cellRadius; ++z)
				{
					var cell = centerCell + new Vector3Int(x, y, z);

					if (!cells[generated].TryGetValue(cell, out list))
						continue;

					for (int i = list.Count - 1; i >= 0; --i)
					{
						GameObject candidate = list[i].go;
						Vector3 p = candidate.transform.position;

						float dx = Mathf.Abs(p.x - center.x);
						float dy = Mathf.Abs(p.y - center.y);
						float dz = Mathf.Abs(p.z - center.z);

						if (dx <= halfSize && dy <= halfSize && dz <= halfSize)
						{
							list.RemoveAt(i);
						}
					}

					if (list.Count == 0)
						cells[generated].Remove(cell);
				}
	}

	public List<GameInfo> GetInBoxWithSize(Vector3 center, Vector3 size, Generated generated)
	{
		gen_test(generated);
		reuseList.Clear();

		float halfX = size.x * 0.5f;
		float halfY = size.y * 0.5f;
		float halfZ = size.z * 0.5f;

		var centerCell = GetCell(center);

		int cellRadiusX = Mathf.CeilToInt(halfX / cellSize) + 1;
		int cellRadiusY = Mathf.CeilToInt(halfY / cellSize) + 1;
		int cellRadiusZ = Mathf.CeilToInt(halfZ / cellSize) + 1;

		List<GameInfo> list;

		for (int x = -cellRadiusX; x <= cellRadiusX; ++x)
			for (int y = -cellRadiusY; y <= cellRadiusY; ++y)
				for (int z = -cellRadiusZ; z <= cellRadiusZ; ++z)
				{
					var cell = centerCell + new Vector3Int(x, y, z);

					if (!cells[generated].TryGetValue(cell, out list))
						continue;

					foreach (var obj in list)
					{
						Vector3 p = obj.go.transform.position;

						float dx = Mathf.Abs(p.x - center.x);
						float dy = Mathf.Abs(p.y - center.y);
						float dz = Mathf.Abs(p.z - center.z);

						if (dx <= halfX && dy <= halfY && dz <= halfZ)
							reuseList.Add(obj);
					}
				}

		return reuseList;
	}

	public List<GameInfo> GetAllInCell(Vector3 vec, Generated generated)
	{
		gen_test(generated);
		var cell = GetCell(vec);
		List<GameInfo> list;
		if (cells[generated].TryGetValue(cell, out list))
		{
			return list;
		}
		return new List<GameInfo>();
	}

	private GameObject t(GameInfo gi) { return gi.go; }
	public List<GameObject> GetAllInCellGo(Vector3 vec, Generated generated)
	{
		gen_test(generated);
		var cell = GetCell(vec);
		List<GameInfo> list;
		if (cells[generated].TryGetValue(cell, out list))
		{
			return World_command.ProcessObjects<GameInfo, GameObject>(list, selector: t);
		}
		return new List<GameObject>();
	}

	public List<GameInfo> GetInBox(Vector3 center, float halfSize, Generated generated)
	{
		reuseList.Clear();

		var centerCell = GetCell(center);
		float cellRadius = halfSize / cellSize + 1;
		List<GameInfo> list;

		gen_test(generated);

		for (float x = -cellRadius; x <= cellRadius; ++x)
			for (float y = -cellRadius; y <= cellRadius; ++y)
				for (float z = -cellRadius; z <= cellRadius; ++z)
				{
					var cell = centerCell + new Vector3Int(x, y, z);

					if (!cells[generated].TryGetValue(cell, out list))
						continue;

					foreach (var obj in list)
					{
						Vector3 p = obj.go.transform.position;

						float dx = Mathf.Abs(p.x - center.x);
						float dy = Mathf.Abs(p.y - center.y);
						float dz = Mathf.Abs(p.z - center.z);

						if (dx <= halfSize && dy <= halfSize && dz <= halfSize)
							reuseList.Add(obj);
					}
				}

		return reuseList;
	}
}

class TypeStConv
{
	public static string TypeInSt(Type t)
	{
		return t.AssemblyQualifiedName;
	}

	public static Type StInType(string st)
	{
		if (string.IsNullOrEmpty(st)) return null;
		return Type.GetType(st, throwOnError: false, ignoreCase: false);
	}
}

public class Str
{
	public static int Count(string st, string ch)
	{
		return st.Length - st.Replace(ch, "").Length;
	}

	public static int StrCount(string st, char simbul)
	{
		int i = 0;
		foreach (char j in st)
		{
			if (j == simbul)
			{
				i++;
			}
		}
		return i;
	}

	public static string StDelBlock(string st, char stc, char fc)
	{
		if (string.IsNullOrEmpty(st))
			return st;

		int start = st.IndexOf(stc);
		int end = st.LastIndexOf(fc);

		if (start >= 0 && end > start)
		{
			int blockLength = end - start + 1;
			string before = st.Substring(0, start);
			string after = st.Substring(end + 1);
			return before + after;
		}

		return st;
	}

	public static string StDelNotInLpRp(string input, char stc, char fc)
	{
		if (string.IsNullOrEmpty(input))
			return "";

		int start = input.IndexOf(stc);
		if (start < 0)
			return "";

		int end = input.IndexOf(fc, start);
		if (end <= start)
			return "";

		return input.Substring(start + 1, end - start - 1);
	}

	public static string StObrez(string st, int min, int max)
	{
		if (string.IsNullOrEmpty(st))
			return st;

		if (min > max)
		{
			int temp = min;
			min = max;
			max = temp;
		}

		if (min < 0) min = 0;
		if (max > st.Length) max = st.Length;

		if (min >= max)
			return st;

		int count = max - min;
		return st.Remove(min, count);
	}

	public static string StObrezIndexOfMin(string st, char ch)
	{
		if (string.IsNullOrEmpty(st))
			return st;

		int idx = st.IndexOf(ch);
		if (idx == -1)
			return st;

		return StObrez(st, 0, idx);
	}
	public static string StObrezIndexOfMinLast(string st, char ch)
	{
		if (string.IsNullOrEmpty(st))
			return st;

		int idx = st.LastIndexOf(ch);
		if (idx == -1)
			return st;

		return StObrez(st, 0, idx);
	}
	public static string StObrezIndexOfMax(string st, char ch)
	{
		if (string.IsNullOrEmpty(st))
			return st;

		int idx = st.IndexOf(ch);
		if (idx == -1)
			return st;

		return st.Remove(idx);
	}
	public static string StObrezIndexOfMaxLast(string st, char ch)
	{
		if (string.IsNullOrEmpty(st))
			return st;

		int idx = st.LastIndexOf(ch);
		if (idx == -1)
			return st;

		return st.Remove(idx);
	}

}

public class DicConv
{
	[Serializable]
	public class KeyValuePairCl<T, T2>
	{
		public T Key;
		public T2 Value;
		public KeyValuePairCl(T t, T2 t2)
		{
			Key = t;
			Value = t2;
		}
	}

	public static List<KeyValuePairCl<T, T2>> DicToList<T, T2>(Dictionary<T, T2> dic)
	{
		if (dic == null) return new List<KeyValuePairCl<T, T2>>();
		List<KeyValuePairCl<T, T2>> t = new List<KeyValuePairCl<T, T2>>();
		foreach(var i in dic)
		{
			t.Add(new KeyValuePairCl<T, T2>(i.Key, i.Value));
		}
		return t;
	}

	public static Dictionary<T, T2> ListToDic<T, T2>(List<KeyValuePairCl<T, T2>> l)
	{
		if (l == null) return null;
		Dictionary<T, T2> dic = new Dictionary<T, T2>();
		for(int i = 0; i < l.Count; i++)
		{
			dic[l[i].Key] = l[i].Value;
		}
		return dic;
	}
}

[Serializable]
public class JsonP
{
	public Dictionary<string, KVP> json { get; private set; }
	public Dictionary<string, KVP>.KeyCollection Keys { get { return json.Keys; } }
	public readonly string t;
	public Type type() { Type ty = Type.GetType(this.t, throwOnError: false, ignoreCase: false); return ty; }

	[Serializable]
	public class KVP
	{
		public string type { get; private set; }
		public string value { get; private set; }

		public KVP(string type, string value)
		{
			if (type == null) World_command.Error("KVP", "type == null");
			this.type = type;
			this.value = value;
		}
	}

	public JsonP() { t = TypeStConv.TypeInSt(typeof(object)); json = new Dictionary<string, KVP>(); }
	public JsonP(Type t) { this.t = TypeStConv.TypeInSt(t); json = new Dictionary<string, KVP>(); }

	public JsonP(string jsons) { t = TypeStConv.TypeInSt(typeof(object)); json = ToJson(jsons); }
	public JsonP(string jsons, Type t) { this.t = TypeStConv.TypeInSt(t); json = ToJson(jsons); }

	public JsonP(JsonP jp) { t = TypeStConv.TypeInSt(typeof(object)); json = jp.json; }
	public JsonP(JsonP jp, Type t) { this.t = TypeStConv.TypeInSt(t); json = jp.json; }

	public JsonP(Dictionary<string, KVP> dic) { t = TypeStConv.TypeInSt(typeof(object)); json = new Dictionary<string, KVP>(dic); }
	public JsonP(Dictionary<string, KVP> dic, Type t) { this.t = TypeStConv.TypeInSt(t); json = new Dictionary<string, KVP>(dic); }

	public interface JsonPActionClass
	{
		void JsonPAction();
	}

	public interface JsonPActionTClass<T>
	{
		void JsonPAction(T val);
	}

	public static JsonP StToJson(string js)
	{
		if (!IsValidJson(js)) return null;
		var j = JsonUtility.FromJson<DicConv.KeyValuePairCl<string, List<DicConv.KeyValuePairCl<string, KVP>>>>(js);
		if (j == null) return null;
		Type ty = Type.GetType(j.Key, throwOnError: false, ignoreCase: false);
		if (ty == null) return null;
		return new JsonP(DicConv.ListToDic<string, KVP>(j.Value), ty);
	}

	public static string JsonPToSt(JsonP jp)
	{
		return JsonUtility.ToJson(new DicConv.KeyValuePairCl<string, List<DicConv.KeyValuePairCl<string, KVP>>>(jp.t, DicConv.DicToList<string, KVP>(jp.json)));
	}

	private static T DeSer<T>(KVP d)
	{
		string t = Str.StDelNotInLpRp(d.value, '(', ')');
		string v = Str.StDelBlock(d.value, '(', ')');
		if(!string.IsNullOrEmpty(t) && !string.IsNullOrEmpty(v) && IsValidJson(v) && TypeStConv.StInType(d.type) == typeof(JsonP))
		{
			return (T)(object)(new JsonP(JsonP.ToJson(v),  TypeStConv.StInType(t)));
		}
		return JsonUtility.FromJson<T>(d.value);
	}

	private static string Ser(object obj)
	{
		var dict = obj as JsonP;
		if (dict != null)
		{
			return "(" + dict.t + ")" + JsonP.JsonToSt(dict.json);
		}

		return JsonUtility.ToJson(obj);
	}

	public void Add<T>(string key, T val) {
		if (json.ContainsKey(key)) World_command.Error("JsonP", "created (value != null) = new value");
		if (type() != typeof(object) && !type().IsAssignableFrom(val.GetType())) World_command.Error("JsonP", "Add type != Init type");
		string t = val == null ? "" : val.GetType().FullName;
		json.Add(key, new KVP(t, Ser(val)));
	}

	public void AddPath<T>(string path, T value)
	{
		string st = Str.StObrezIndexOfMin(path, '/');
		string stp = Str.StObrezIndexOfMax(path, '/');
		if (stp.Length != 0 && path.Contains("/"))
		{
			JsonP jp = TryGet<JsonP>(st);
			if (jp == null) return;
			jp.AddPath<T>(stp, value);
		}
		else
		{
			Add<T>(stp, value);
		}
	}

	public void Reduct<T>(string key, T val) {
		if (!json.ContainsKey(key)) World_command.Error("JsonP", "not key [\"" + key + "\"] in JsonP");
		if (type() != typeof(object) && !type().IsAssignableFrom(val.GetType())) World_command.Error("JsonP", "Add type != Init type");
		string t = val == null ? "" : val.GetType().FullName;
		json[key] = new KVP(t, JsonUtility.ToJson(Ser(val)));
	}

	public void ReductPath<T>(string path, T value)
	{
		string st = Str.StObrezIndexOfMin(path, '/');
		string stp = Str.StObrezIndexOfMax(path, '/');
		if (stp.Length != 0 && path.Contains("/"))
		{
			JsonP jp = TryGet<JsonP>(st);
			if (jp == null) return;
			jp.ReductPath<T>(stp, value);
		}
		else
		{
			Reduct<T>(stp, value);
		}
	}

	public T Get<T>(string key)
	{
		KVP st;
		if (!json.TryGetValue(key, out st) || string.IsNullOrEmpty(st.type) || string.IsNullOrEmpty(st.value))
		{
			if (!type().IsAssignableFrom(typeof(T)) && type() != typeof(object)) World_command.Error("JsonP", "Add type != Init type");
			World_command.Error("JsonP", "not key in json");
			return default(T);
		}
		return DeSer<T>(st);
	}

	public T GetPath<T>(string path)
	{
		string st = Str.StObrezIndexOfMin(path, '/');
		string stp = Str.StObrezIndexOfMax(path, '/');
		if (stp.Length != 0 && path.Contains("/"))
		{
			JsonP jp = TryGet<JsonP>(st);
			if (jp == null) { World_command.Error("JsonP", "not key in json"); return default(T); }
			return jp.GetPath<T>(stp);
		}
		else
		{
			return Get<T>(stp);
		}
	}

	public T TryGet<T>(string key, T defult = default(T))
	{
		KVP st;
		if (!type().IsAssignableFrom(typeof(T)) && type() != typeof(object)) World_command.Error("JsonP", "Add type != Init type");
		if (!json.TryGetValue(key, out st) || string.IsNullOrEmpty(st.type) || string.IsNullOrEmpty(st.value))
		{
			return defult;
		}
		return DeSer<T>(st);
	}

	public T TryGetPath<T>(string path)
	{
		string st = Str.StObrezIndexOfMin(path, '/');
		string stp = Str.StObrezIndexOfMax(path, '/');
		if (stp.Length != 0 && path.Contains("/"))
		{
			JsonP jp = TryGet<JsonP>(st);
			if (jp == null) return default(T);
			return jp.TryGetPath<T>(stp);
		}
		else
		{
			return Get<T>(stp);
		}
	}

	public bool TryGetValue<T>(string key)
	{
		KVP st;
		if (!type().IsAssignableFrom(typeof(T)) && type() != typeof(object)) World_command.Error("JsonP", "Add type != Init type");
		if (!json.TryGetValue(key, out st) || string.IsNullOrEmpty(st.type) || string.IsNullOrEmpty(st.value))
		{
			return false;
		}
		return true;
	}

	public bool TryGetValue<T>(string key, out T val)
	{
		KVP st;
		if (!type().IsAssignableFrom(typeof(T)) && type() != typeof(object)) World_command.Error("JsonP", "Add type != Init type");
		if (!json.TryGetValue(key, out st) || string.IsNullOrEmpty(st.type) || string.IsNullOrEmpty(st.value))
		{
			val = default(T);
			return false;
		}
		val = DeSer<T>(st);
		return true;
	}

	public bool TryGetValuePath<T>(string path)
	{
		KVP res;
		string st = Str.StObrezIndexOfMin(path, '/');
		string stp = Str.StObrezIndexOfMax(path, '/');
		if (stp.Length != 0 && path.Contains("/"))
		{
			JsonP jp = TryGet<JsonP>(st);
			if (jp == null) return false;
			return jp.TryGetValuePath<T>(stp);
		}
		else
		{
			return json.TryGetValue(st, out res) && !string.IsNullOrEmpty(res.type) || !string.IsNullOrEmpty(res.value);
		}
	}

	public bool TryGetValuePath<T>(string path, out T val)
	{
		KVP res;
		string st = Str.StObrezIndexOfMin(path, '/');
		string stp = Str.StObrezIndexOfMax(path, '/');
		if (stp.Length != 0 && path.Contains("/"))
		{
			JsonP jp = TryGet<JsonP>(st);
			if (jp == null) { val = default(T); return false; }
			T vp;
			bool b = jp.TryGetValuePath<T>(stp, out vp);
			val = vp;
			return b;
		}
		else
		{
			bool b = json.TryGetValue(st, out res) && !string.IsNullOrEmpty(res.type) || !string.IsNullOrEmpty(res.value);
			val = Get<T>(st);
			return b;
		}
	}

	public Dictionary<string, T> GetCopyDicJsonP<T>()
	{
		Dictionary<string, T> dic = new Dictionary<string, T>();
		foreach(var i in Keys)
		{
			T ty = TryGet<T>(i);
			if ((object)ty == (object)default(T)) continue;
			dic.Add(i, ty);
		}
		return dic;
	}

	public override string ToString()
	{
		return JsonToSt(json);
	}

	public static bool IsValidJson(string json)
	{
		if (string.IsNullOrEmpty(json)) return false;

		var dummy = new JsonWrapper();
		try
		{
			JsonUtility.FromJsonOverwrite(json, dummy);
			return true;
		}
		catch
		{
			return false;
		}
	}

	public static string JsonToSt(Dictionary<string, KVP> st)
	{
		var dic = new Dictionary<string, string>();
		foreach(var i in st)
		{
			if (i.Value.type == typeof(JsonP).Name)
			{
				dic[i.Key] = "(" + i.Value.type + ")" + (new JsonP(i.Value.value)).ToString();
			}
			else
			{
				dic[i.Key] = "(" + i.Value.type + ")" + JsonUtility.ToJson(i.Value.value);
			}
		}

		string s = "{";
		foreach(var i in dic)
		{
			s += i.Key;
			s += ": ";
			s += i.Value;
			s += ",";
		}
		s += "}";

		return s;
	}

	public static Dictionary<string, KVP> ToJson(string st)
	{
		if (string.IsNullOrEmpty(st) || st.Length < 2)
			return new Dictionary<string, KVP>();

		var dic = new Dictionary<string, KVP>();
		string s = st.Substring(1, st.Length-2);

		foreach(var i in s.Split(','))
		{
			if(Str.Count(i, ":") == 1)
			{
				string[] sm = i.Split(':');
				string typ = Str.StDelNotInLpRp(sm[1], '(', ')');
				string val = Str.StDelBlock(sm[1], '(', ')');
				if (typ == typeof(JsonP).Name) {
					JsonP ser = DeSer<JsonP>(new KVP(typeof(JsonP).Name, val));
					dic[sm[0]] = new KVP(typ, ser.ToString());
				} else
				{
					dic[sm[0]] = new KVP(typ, val);
				}
			} else { return new Dictionary<string, KVP>(); }
		}

		return dic;
    }

	[System.Serializable]
	private class JsonWrapper
	{
		public Dictionary<string, string> Data;
	}
}

public class World_command
{
	public enum Date_move
	{
		INPUT,
		OUTPUT
	}

	public enum Napr
	{
		BACK,
		FRONT,
		TOP,
		BOTTOM,
		LEFT,
		RIGHT
	}

	public static List<T> ListNotDoble<T>(List<T> lst)
	{
		return new List<T>(new HashSet<T>(lst));
	}

	public static List<TResult> ProcessObjects<TSource, TResult>(
		List<TSource> source,
		Func<TSource, bool> filter = null,
		Func<TSource, TResult> selector = null
	)
	{

		if (source == null)
			throw new ArgumentNullException("source");

		if (filter == null && selector == null)
			return new List<TResult>();

		var result = new List<TResult>(source.Count);

		foreach (var item in source)
		{
			if (filter != null && !filter(item))
				continue;

			TResult value;

			if (selector != null)
			{
				value = selector(item);
			}
			else
			{
				if (item is TResult)
				{
					value = (TResult)(object)item;
				}
				else
				{
					throw new InvalidCastException(
						"Cannot convert " + typeof(TSource).Name + " to " + typeof(TResult).Name +
						" without selector.");
				}
			}

			result.Add(value);
		}

		return result;
	}

	public static World_command.Napr GetSideFacing(Transform source, Vector3 targetPos)
	{
		Vector3 dir = (targetPos - source.position).normalized;

		float f = Vector3.Dot(dir, source.forward);
		float b = Vector3.Dot(dir, -source.forward);
		float r = Vector3.Dot(dir, source.right);
		float l = Vector3.Dot(dir, -source.right);
		float u = Vector3.Dot(dir, source.up);
		float d = Vector3.Dot(dir, -source.up);

		float max = f;
		World_command.Napr result = World_command.Napr.FRONT;

		if (b > max) { max = b; result = World_command.Napr.BACK; }
		if (r > max) { max = r; result = World_command.Napr.RIGHT; }
		if (l > max) { max = l; result = World_command.Napr.LEFT; }
		if (u > max) { max = u; result = World_command.Napr.TOP; }
		if (d > max) { max = d; result = World_command.Napr.BOTTOM; }

		return result;
	}

	public static void Error(string name, string err)
	{
		Debug.LogError("[Script(\"" + name + "\")] " + err);
		throw new Exception("[Script(\"" + name + "\")] " + err);
	}

	public static List<Vector3> GetCellCenters(GameObject g1)
	{
		const float cubeSize = 1f;
		var result = new List<Vector3>();

		var box = g1.GetComponent<BoxCollider>();
		if (box == null)
			return result;

		Vector3 center = box.center;
		Vector3 size = box.size;
		Vector3 min = center - size / 2f;

		int countX = Mathf.Max(1, Mathf.FloorToInt(size.x / cubeSize));
		int countY = Mathf.Max(1, Mathf.FloorToInt(size.y / cubeSize));
		int countZ = Mathf.Max(1, Mathf.FloorToInt(size.z / cubeSize));

		float stepX = size.x / countX;
		float stepY = size.y / countY;
		float stepZ = size.z / countZ;

		var t = g1.transform;

		Vector3Int vect;

		for (int ix = 0; ix < countX; ix++)
			for (int iy = 0; iy < countY; iy++)
				for (int iz = 0; iz < countZ; iz++)
				{
					Vector3 localCenter = new Vector3(
						min.x + stepX * (ix + 0.5f),
						min.y + stepY * (iy + 0.5f),
						min.z + stepZ * (iz + 0.5f)
					);
					vect = new Vector3Int(t.TransformPoint(localCenter));
					result.Add(vect.ToVector3());
				}

		return result;
	}

	public static Dictionary<Napr, List<List<Vector3>>> GetSurfaceCoordsBySide(GameObject obj, Vector3 size)
	{
		int cellsX = Mathf.Max(Mathf.RoundToInt(size.x), 1);
		int cellsY = Mathf.Max(Mathf.RoundToInt(size.y), 1);
		int cellsZ = Mathf.Max(Mathf.RoundToInt(size.z), 1);

		const float cellSize = 1f;
		const float halfCell = 0.5f;

		Vector3 minLocal = Vector3.zero - (size * 0.5f);
		Vector3 maxLocal = Vector3.zero + (size * 0.5f);

		Transform t = obj.transform;

		var res = new Dictionary<Napr, List<List<Vector3>>>(6);

		// FRONT
		var frontRows = new List<List<Vector3>>(cellsY);
		for (int y = 0; y < cellsY; y++)
		{
			var row = new List<Vector3>(cellsX);
			float cy = minLocal.y + (y + halfCell) * cellSize;
			for (int x = 0; x < cellsX; x++)
			{
				float cx = minLocal.x + (x + halfCell) * cellSize;
				row.Add(t.TransformPoint(new Vector3(cx, cy, maxLocal.z + halfCell)));
			}
			frontRows.Add(row);
		}
		res[Napr.FRONT] = frontRows;

		// BACK
		var backRows = new List<List<Vector3>>(cellsY);
		for (int y = 0; y < cellsY; y++)
		{
			var row = new List<Vector3>(cellsX);
			float cy = minLocal.y + (y + halfCell) * cellSize;
			for (int x = 0; x < cellsX; x++)
			{
				float cx = minLocal.x + (x + halfCell) * cellSize;
				row.Add(t.TransformPoint(new Vector3(cx, cy, minLocal.z - halfCell)));
			}
			backRows.Add(row);
		}
		res[Napr.BACK] = backRows;

		// TOP
		var topRows = new List<List<Vector3>>(cellsZ);
		for (int z = 0; z < cellsZ; z++)
		{
			var row = new List<Vector3>(cellsX);
			float cz = minLocal.z + (z + halfCell) * cellSize;
			for (int x = 0; x < cellsX; x++)
			{
				float cx = minLocal.x + (x + halfCell) * cellSize;
				row.Add(t.TransformPoint(new Vector3(cx, maxLocal.y + halfCell, cz)));
			}
			topRows.Add(row);
		}
		res[Napr.TOP] = topRows;

		// BOTTOM
		var bottomRows = new List<List<Vector3>>(cellsZ);
		for (int z = 0; z < cellsZ; z++)
		{
			var row = new List<Vector3>(cellsX);
			float cz = minLocal.z + (z + halfCell) * cellSize;
			for (int x = 0; x < cellsX; x++)
			{
				float cx = minLocal.x + (x + halfCell) * cellSize;
				row.Add(t.TransformPoint(new Vector3(cx, minLocal.y - halfCell, cz)));
			}
			bottomRows.Add(row);
		}
		res[Napr.BOTTOM] = bottomRows;

		// RIGHT
		var rightRows = new List<List<Vector3>>(cellsY);
		for (int y = 0; y < cellsY; y++)
		{
			var row = new List<Vector3>(cellsZ);
			float cy = minLocal.y + (y + halfCell) * cellSize;
			for (int z = 0; z < cellsZ; z++)
			{
				float cz = minLocal.z + (z + halfCell) * cellSize;
				row.Add(t.TransformPoint(new Vector3(maxLocal.x + halfCell, cy, cz)));
			}
			rightRows.Add(row);
		}
		res[Napr.RIGHT] = rightRows;

		// LEFT
		var leftRows = new List<List<Vector3>>(cellsY);
		for (int y = 0; y < cellsY; y++)
		{
			var row = new List<Vector3>(cellsZ);
			float cy = minLocal.y + (y + halfCell) * cellSize;
			for (int z = 0; z < cellsZ; z++)
			{
				float cz = minLocal.z + (z + halfCell) * cellSize;
				row.Add(t.TransformPoint(new Vector3(minLocal.x - halfCell, cy, cz)));
			}
			leftRows.Add(row);
		}
		res[Napr.LEFT] = leftRows;

		return res;
	}

}

public abstract class Error_duble_obg : MonoBehaviour
{
	protected virtual System.Type GetGroupType()
	{
		return GetType();
	}

	private void OnValidate()
	{
		var myGroup = GetGroupType();
		var all = GetComponents<Error_duble_obg>();

		int count = 0;
		string existingNames = "";

		foreach (var comp in all)
		{
			if (comp.GetGroupType() == myGroup)
			{
				count++;

				if (!ReferenceEquals(comp, this))
				{
					existingNames += comp.GetType().Name + " (" + comp.gameObject.name + "), ";
				}
			}
		}

		if (count > 1)
		{
			World_command.Error(gameObject.name, string.Format(
				"[G_Base Protection] Conflict on '{0}': multiple components in group '{1}'. " +
				"Found: {2}. This component ({3}) will be destroyed.",
				gameObject.name,
				myGroup.Name,
				existingNames.TrimEnd(',', ' '),
				GetType().Name));

			Destroy(this);
		}
	}

	protected virtual void OnV() { }
}

public abstract class Errors : Error_duble_obg
{
	private List<Errors> err = new List<Errors>();
	protected virtual bool UpTestError() { return true; }
	protected virtual bool AwTestError() { return true; }
	protected virtual bool StTestError() { return true; }

	private void Awake()
	{
		err = new List<Errors>(FindObjectsOfType<Errors>());
		foreach (var e in err)
		{
			if (e != null && !e.AwTestError())
			{
				World_command.Error(gameObject.name, "Test_feiled");
				return;
			}
		}
		return;
	}

	private void Start()
	{
		foreach (var e in err)
		{
			if (e != null && !e.StTestError())
			{
				World_command.Error(gameObject.name, "Test_feiled");
				return;
			}
		}
		return;
	}

	private void Update()
	{
		foreach (var e in err)
		{
			if (e != null && !e.UpTestError())
			{
				World_command.Error(gameObject.name, "Test_feiled");
				return;
			}
		}
		return;
	}
}

public abstract class Triger : Errors
{
	public virtual void Trigers(MainSystemTrigers.trig tr) { }
}

public abstract class World_class_block_world : Triger
{
	protected sealed override System.Type GetGroupType() { return this.GetType().BaseType; }

	[System.Serializable]
	public sealed class Date_two_list
	{
		[Delayed] public int x = 0;
		[Delayed] public int y = 0;
		public World_command.Napr napr = World_command.Napr.FRONT;
	}

	public struct CoordKey
	{
		public readonly int x;
		public readonly int y;
		public readonly World_command.Napr n;

		public CoordKey(int x, int y, World_command.Napr n)
		{
			this.x = x;
			this.y = y;
			this.n = n;
		}

		public override bool Equals(object obj)
		{
			// Сначала проверяем тип, отдельно
			if (obj == null || obj.GetType() != typeof(CoordKey))
				return false;

			// Теперь безопасно приводим к структуре
			CoordKey other = (CoordKey)obj;
			return x == other.x && y == other.y && n == other.n;
		}

		public override int GetHashCode()
		{
			unchecked
			{
				int hash = 17;
				hash = hash * 31 + x.GetHashCode();
				hash = hash * 31 + y.GetHashCode();
				hash = hash * 31 + n.GetHashCode();
				return hash;
			}
		}
	}

}

public abstract class World_class_move : World_class_block_world
{
	public abstract Vector3 GetSize();
	public abstract bool test_napr_get(GameObject g, World_command.Date_move dm);
	public abstract string get_ore(GameObject po);
	public abstract List<Date_two_list> get_napr(Vector3 vec);
}

public abstract class IF_move_functional : Triger
{
	public abstract void Up_Func_Ore(List<GameObject> gam_inp, List<GameObject> gam_out);
	public abstract string move_ore();
	public abstract string get_ore_entity(GameObject entity, string ore, int len_ore = 1);
}